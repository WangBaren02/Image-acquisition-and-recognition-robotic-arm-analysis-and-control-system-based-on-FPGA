<sld_project_info>
  <sld_infos>
    <sld_info hpath="robotic_arm_low_clk:robotic_arm_low_clk_inst|catch:catch_inst|inverse_kinematics_cordic:inverse_kinematics_cordic_inst|cordic_ATAN2:cordic_ATAN2_inst|atan2:u0" name="u0">
      <assignment_values>
        <assignment_value text="QSYS_NAME atan2 HAS_SOPCINFO 1 GENERATION_ID 1755077459"/>
      </assignment_values>
    </sld_info>
    <sld_info hpath="sld_hub:auto_hub|alt_sld_fab:\instrumentation_fabric_with_node_gen:instrumentation_fabric" library="alt_sld_fab" name="instrumentation_fabric">
      <assignment_values>
        <assignment_value text="QSYS_NAME alt_sld_fab HAS_SOPCINFO 1"/>
      </assignment_values>
    </sld_info>
  </sld_infos>
</sld_project_info>
