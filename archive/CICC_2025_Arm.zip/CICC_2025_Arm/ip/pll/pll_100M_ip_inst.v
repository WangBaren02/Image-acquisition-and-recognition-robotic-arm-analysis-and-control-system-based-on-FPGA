pll_100M_ip	pll_100M_ip_inst (
	.areset ( areset_sig ),
	.inclk0 ( inclk0_sig ),
	.c0 ( c0_sig ),
	.c1 ( c1_sig ),
	.locked ( locked_sig )
	);
