-- ------------------------------------------------------------------------- 
-- High Level Design Compiler for Intel(R) FPGAs Version 17.1 (Release Build #590)
-- Quartus Prime development tool and MATLAB/Simulink Interface
-- 
-- Legal Notice: Copyright 2017 Intel Corporation.  All rights reserved.
-- Your use of  Intel Corporation's design tools,  logic functions and other
-- software and  tools, and its AMPP partner logic functions, and any output
-- files any  of the foregoing (including  device programming  or simulation
-- files), and  any associated  documentation  or information  are expressly
-- subject  to the terms and  conditions of the  Intel FPGA Software License
-- Agreement, Intel MegaCore Function License Agreement, or other applicable
-- license agreement,  including,  without limitation,  that your use is for
-- the  sole  purpose of  programming  logic devices  manufactured by  Intel
-- and  sold by Intel  or its authorized  distributors. Please refer  to the
-- applicable agreement for further details.
-- ---------------------------------------------------------------------------

-- VHDL created from atan2_CORDIC_0
-- VHDL created on Wed Aug 13 17:31:04 2025


library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.NUMERIC_STD.all;
use IEEE.MATH_REAL.all;
use std.TextIO.all;
use work.dspba_library_package.all;

LIBRARY altera_mf;
USE altera_mf.altera_mf_components.all;
LIBRARY lpm;
USE lpm.lpm_components.all;

entity atan2_CORDIC_0 is
    port (
        x : in std_logic_vector(17 downto 0);  -- sfix18_en8
        y : in std_logic_vector(17 downto 0);  -- sfix18_en8
        q : out std_logic_vector(10 downto 0);  -- sfix11_en8
        clk : in std_logic;
        areset : in std_logic
    );
end atan2_CORDIC_0;

architecture normal of atan2_CORDIC_0 is

    attribute altera_attribute : string;
    attribute altera_attribute of normal : architecture is "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF; -name PHYSICAL_SYNTHESIS_REGISTER_DUPLICATION ON; -name MESSAGE_DISABLE 10036; -name MESSAGE_DISABLE 10037; -name MESSAGE_DISABLE 14130; -name MESSAGE_DISABLE 14320; -name MESSAGE_DISABLE 15400; -name MESSAGE_DISABLE 14130; -name MESSAGE_DISABLE 10036; -name MESSAGE_DISABLE 12020; -name MESSAGE_DISABLE 12030; -name MESSAGE_DISABLE 12010; -name MESSAGE_DISABLE 12110; -name MESSAGE_DISABLE 14320; -name MESSAGE_DISABLE 13410; -name MESSAGE_DISABLE 113007";
    
    signal GND_q : STD_LOGIC_VECTOR (0 downto 0);
    signal VCC_q : STD_LOGIC_VECTOR (0 downto 0);
    signal constantZero_uid6_atan2Test_q : STD_LOGIC_VECTOR (17 downto 0);
    signal signX_uid7_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal signY_uid8_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal invSignX_uid9_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal absXE_uid10_atan2Test_a : STD_LOGIC_VECTOR (19 downto 0);
    signal absXE_uid10_atan2Test_b : STD_LOGIC_VECTOR (19 downto 0);
    signal absXE_uid10_atan2Test_o : STD_LOGIC_VECTOR (19 downto 0);
    signal absXE_uid10_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal absXE_uid10_atan2Test_q : STD_LOGIC_VECTOR (18 downto 0);
    signal invSignY_uid11_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal absYE_uid12_atan2Test_a : STD_LOGIC_VECTOR (19 downto 0);
    signal absYE_uid12_atan2Test_b : STD_LOGIC_VECTOR (19 downto 0);
    signal absYE_uid12_atan2Test_o : STD_LOGIC_VECTOR (19 downto 0);
    signal absYE_uid12_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal absYE_uid12_atan2Test_q : STD_LOGIC_VECTOR (18 downto 0);
    signal absX_uid13_atan2Test_in : STD_LOGIC_VECTOR (17 downto 0);
    signal absX_uid13_atan2Test_b : STD_LOGIC_VECTOR (17 downto 0);
    signal absY_uid14_atan2Test_in : STD_LOGIC_VECTOR (17 downto 0);
    signal absY_uid14_atan2Test_b : STD_LOGIC_VECTOR (17 downto 0);
    signal yNotZero_uid15_atan2Test_qi : STD_LOGIC_VECTOR (0 downto 0);
    signal yNotZero_uid15_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal yZero_uid16_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xNotZero_uid17_atan2Test_qi : STD_LOGIC_VECTOR (0 downto 0);
    signal xNotZero_uid17_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xZero_uid18_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal cstArcTan2Mi_0_uid22_atan2Test_q : STD_LOGIC_VECTOR (19 downto 0);
    signal xip1E_1_uid23_atan2Test_a : STD_LOGIC_VECTOR (18 downto 0);
    signal xip1E_1_uid23_atan2Test_b : STD_LOGIC_VECTOR (18 downto 0);
    signal xip1E_1_uid23_atan2Test_o : STD_LOGIC_VECTOR (18 downto 0);
    signal xip1E_1_uid23_atan2Test_q : STD_LOGIC_VECTOR (18 downto 0);
    signal yip1E_1_uid24_atan2Test_a : STD_LOGIC_VECTOR (18 downto 0);
    signal yip1E_1_uid24_atan2Test_b : STD_LOGIC_VECTOR (18 downto 0);
    signal yip1E_1_uid24_atan2Test_o : STD_LOGIC_VECTOR (18 downto 0);
    signal yip1E_1_uid24_atan2Test_q : STD_LOGIC_VECTOR (18 downto 0);
    signal lowRangeB_uid25_atan2Test_in : STD_LOGIC_VECTOR (18 downto 0);
    signal lowRangeB_uid25_atan2Test_b : STD_LOGIC_VECTOR (18 downto 0);
    signal highBBits_uid26_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_1_uid28_atan2Test_q : STD_LOGIC_VECTOR (21 downto 0);
    signal aip1E_uid31_atan2Test_in : STD_LOGIC_VECTOR (20 downto 0);
    signal aip1E_uid31_atan2Test_b : STD_LOGIC_VECTOR (20 downto 0);
    signal xMSB_uid32_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal cstArcTan2Mi_1_uid36_atan2Test_q : STD_LOGIC_VECTOR (20 downto 0);
    signal invSignOfSelectionSignal_uid37_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_2NA_uid39_atan2Test_q : STD_LOGIC_VECTOR (19 downto 0);
    signal xip1E_2sumAHighB_uid40_atan2Test_a : STD_LOGIC_VECTOR (22 downto 0);
    signal xip1E_2sumAHighB_uid40_atan2Test_b : STD_LOGIC_VECTOR (22 downto 0);
    signal xip1E_2sumAHighB_uid40_atan2Test_o : STD_LOGIC_VECTOR (22 downto 0);
    signal xip1E_2sumAHighB_uid40_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_2sumAHighB_uid40_atan2Test_q : STD_LOGIC_VECTOR (21 downto 0);
    signal yip1E_2NA_uid42_atan2Test_q : STD_LOGIC_VECTOR (19 downto 0);
    signal yip1E_2sumAHighB_uid43_atan2Test_a : STD_LOGIC_VECTOR (21 downto 0);
    signal yip1E_2sumAHighB_uid43_atan2Test_b : STD_LOGIC_VECTOR (21 downto 0);
    signal yip1E_2sumAHighB_uid43_atan2Test_o : STD_LOGIC_VECTOR (21 downto 0);
    signal yip1E_2sumAHighB_uid43_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_2sumAHighB_uid43_atan2Test_q : STD_LOGIC_VECTOR (20 downto 0);
    signal aip1E_2CostZeroPaddingA_uid45_atan2Test_q : STD_LOGIC_VECTOR (1 downto 0);
    signal aip1E_2NA_uid46_atan2Test_q : STD_LOGIC_VECTOR (22 downto 0);
    signal aip1E_2sumAHighB_uid47_atan2Test_a : STD_LOGIC_VECTOR (24 downto 0);
    signal aip1E_2sumAHighB_uid47_atan2Test_b : STD_LOGIC_VECTOR (24 downto 0);
    signal aip1E_2sumAHighB_uid47_atan2Test_o : STD_LOGIC_VECTOR (24 downto 0);
    signal aip1E_2sumAHighB_uid47_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_2sumAHighB_uid47_atan2Test_q : STD_LOGIC_VECTOR (23 downto 0);
    signal xip1_2_uid48_atan2Test_in : STD_LOGIC_VECTOR (19 downto 0);
    signal xip1_2_uid48_atan2Test_b : STD_LOGIC_VECTOR (19 downto 0);
    signal yip1_2_uid49_atan2Test_in : STD_LOGIC_VECTOR (19 downto 0);
    signal yip1_2_uid49_atan2Test_b : STD_LOGIC_VECTOR (19 downto 0);
    signal aip1E_uid50_atan2Test_in : STD_LOGIC_VECTOR (22 downto 0);
    signal aip1E_uid50_atan2Test_b : STD_LOGIC_VECTOR (22 downto 0);
    signal xMSB_uid51_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal cstArcTan2Mi_2_uid55_atan2Test_q : STD_LOGIC_VECTOR (21 downto 0);
    signal invSignOfSelectionSignal_uid56_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_3NA_uid58_atan2Test_q : STD_LOGIC_VECTOR (21 downto 0);
    signal xip1E_3sumAHighB_uid59_atan2Test_a : STD_LOGIC_VECTOR (24 downto 0);
    signal xip1E_3sumAHighB_uid59_atan2Test_b : STD_LOGIC_VECTOR (24 downto 0);
    signal xip1E_3sumAHighB_uid59_atan2Test_o : STD_LOGIC_VECTOR (24 downto 0);
    signal xip1E_3sumAHighB_uid59_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_3sumAHighB_uid59_atan2Test_q : STD_LOGIC_VECTOR (23 downto 0);
    signal yip1E_3NA_uid61_atan2Test_q : STD_LOGIC_VECTOR (21 downto 0);
    signal yip1E_3sumAHighB_uid62_atan2Test_a : STD_LOGIC_VECTOR (23 downto 0);
    signal yip1E_3sumAHighB_uid62_atan2Test_b : STD_LOGIC_VECTOR (23 downto 0);
    signal yip1E_3sumAHighB_uid62_atan2Test_o : STD_LOGIC_VECTOR (23 downto 0);
    signal yip1E_3sumAHighB_uid62_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_3sumAHighB_uid62_atan2Test_q : STD_LOGIC_VECTOR (22 downto 0);
    signal aip1E_3NA_uid65_atan2Test_q : STD_LOGIC_VECTOR (24 downto 0);
    signal aip1E_3sumAHighB_uid66_atan2Test_a : STD_LOGIC_VECTOR (26 downto 0);
    signal aip1E_3sumAHighB_uid66_atan2Test_b : STD_LOGIC_VECTOR (26 downto 0);
    signal aip1E_3sumAHighB_uid66_atan2Test_o : STD_LOGIC_VECTOR (26 downto 0);
    signal aip1E_3sumAHighB_uid66_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_3sumAHighB_uid66_atan2Test_q : STD_LOGIC_VECTOR (25 downto 0);
    signal xip1_3_uid67_atan2Test_in : STD_LOGIC_VECTOR (21 downto 0);
    signal xip1_3_uid67_atan2Test_b : STD_LOGIC_VECTOR (21 downto 0);
    signal yip1_3_uid68_atan2Test_in : STD_LOGIC_VECTOR (20 downto 0);
    signal yip1_3_uid68_atan2Test_b : STD_LOGIC_VECTOR (20 downto 0);
    signal aip1E_uid69_atan2Test_in : STD_LOGIC_VECTOR (24 downto 0);
    signal aip1E_uid69_atan2Test_b : STD_LOGIC_VECTOR (24 downto 0);
    signal xMSB_uid70_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal cstArcTan2Mi_3_uid74_atan2Test_q : STD_LOGIC_VECTOR (22 downto 0);
    signal invSignOfSelectionSignal_uid75_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_4CostZeroPaddingA_uid76_atan2Test_q : STD_LOGIC_VECTOR (2 downto 0);
    signal xip1E_4NA_uid77_atan2Test_q : STD_LOGIC_VECTOR (24 downto 0);
    signal xip1E_4sumAHighB_uid78_atan2Test_a : STD_LOGIC_VECTOR (27 downto 0);
    signal xip1E_4sumAHighB_uid78_atan2Test_b : STD_LOGIC_VECTOR (27 downto 0);
    signal xip1E_4sumAHighB_uid78_atan2Test_o : STD_LOGIC_VECTOR (27 downto 0);
    signal xip1E_4sumAHighB_uid78_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_4sumAHighB_uid78_atan2Test_q : STD_LOGIC_VECTOR (26 downto 0);
    signal yip1E_4NA_uid80_atan2Test_q : STD_LOGIC_VECTOR (23 downto 0);
    signal yip1E_4sumAHighB_uid81_atan2Test_a : STD_LOGIC_VECTOR (25 downto 0);
    signal yip1E_4sumAHighB_uid81_atan2Test_b : STD_LOGIC_VECTOR (25 downto 0);
    signal yip1E_4sumAHighB_uid81_atan2Test_o : STD_LOGIC_VECTOR (25 downto 0);
    signal yip1E_4sumAHighB_uid81_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_4sumAHighB_uid81_atan2Test_q : STD_LOGIC_VECTOR (24 downto 0);
    signal aip1E_4NA_uid84_atan2Test_q : STD_LOGIC_VECTOR (26 downto 0);
    signal aip1E_4sumAHighB_uid85_atan2Test_a : STD_LOGIC_VECTOR (28 downto 0);
    signal aip1E_4sumAHighB_uid85_atan2Test_b : STD_LOGIC_VECTOR (28 downto 0);
    signal aip1E_4sumAHighB_uid85_atan2Test_o : STD_LOGIC_VECTOR (28 downto 0);
    signal aip1E_4sumAHighB_uid85_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_4sumAHighB_uid85_atan2Test_q : STD_LOGIC_VECTOR (27 downto 0);
    signal xip1_4_uid86_atan2Test_in : STD_LOGIC_VECTOR (24 downto 0);
    signal xip1_4_uid86_atan2Test_b : STD_LOGIC_VECTOR (24 downto 0);
    signal yip1_4_uid87_atan2Test_in : STD_LOGIC_VECTOR (22 downto 0);
    signal yip1_4_uid87_atan2Test_b : STD_LOGIC_VECTOR (22 downto 0);
    signal aip1E_uid88_atan2Test_in : STD_LOGIC_VECTOR (26 downto 0);
    signal aip1E_uid88_atan2Test_b : STD_LOGIC_VECTOR (26 downto 0);
    signal xMSB_uid89_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal cstArcTan2Mi_4_uid93_atan2Test_q : STD_LOGIC_VECTOR (23 downto 0);
    signal invSignOfSelectionSignal_uid94_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_5CostZeroPaddingA_uid95_atan2Test_q : STD_LOGIC_VECTOR (3 downto 0);
    signal xip1E_5NA_uid96_atan2Test_q : STD_LOGIC_VECTOR (28 downto 0);
    signal xip1E_5sumAHighB_uid97_atan2Test_a : STD_LOGIC_VECTOR (31 downto 0);
    signal xip1E_5sumAHighB_uid97_atan2Test_b : STD_LOGIC_VECTOR (31 downto 0);
    signal xip1E_5sumAHighB_uid97_atan2Test_o : STD_LOGIC_VECTOR (31 downto 0);
    signal xip1E_5sumAHighB_uid97_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_5sumAHighB_uid97_atan2Test_q : STD_LOGIC_VECTOR (30 downto 0);
    signal yip1E_5NA_uid99_atan2Test_q : STD_LOGIC_VECTOR (26 downto 0);
    signal yip1E_5sumAHighB_uid100_atan2Test_a : STD_LOGIC_VECTOR (28 downto 0);
    signal yip1E_5sumAHighB_uid100_atan2Test_b : STD_LOGIC_VECTOR (28 downto 0);
    signal yip1E_5sumAHighB_uid100_atan2Test_o : STD_LOGIC_VECTOR (28 downto 0);
    signal yip1E_5sumAHighB_uid100_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_5sumAHighB_uid100_atan2Test_q : STD_LOGIC_VECTOR (27 downto 0);
    signal aip1E_5NA_uid103_atan2Test_q : STD_LOGIC_VECTOR (28 downto 0);
    signal aip1E_5sumAHighB_uid104_atan2Test_a : STD_LOGIC_VECTOR (30 downto 0);
    signal aip1E_5sumAHighB_uid104_atan2Test_b : STD_LOGIC_VECTOR (30 downto 0);
    signal aip1E_5sumAHighB_uid104_atan2Test_o : STD_LOGIC_VECTOR (30 downto 0);
    signal aip1E_5sumAHighB_uid104_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_5sumAHighB_uid104_atan2Test_q : STD_LOGIC_VECTOR (29 downto 0);
    signal xip1_5_uid105_atan2Test_in : STD_LOGIC_VECTOR (28 downto 0);
    signal xip1_5_uid105_atan2Test_b : STD_LOGIC_VECTOR (28 downto 0);
    signal yip1_5_uid106_atan2Test_in : STD_LOGIC_VECTOR (25 downto 0);
    signal yip1_5_uid106_atan2Test_b : STD_LOGIC_VECTOR (25 downto 0);
    signal aip1E_uid107_atan2Test_in : STD_LOGIC_VECTOR (28 downto 0);
    signal aip1E_uid107_atan2Test_b : STD_LOGIC_VECTOR (28 downto 0);
    signal xMSB_uid108_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal twoToMiSiXip_uid112_atan2Test_b : STD_LOGIC_VECTOR (24 downto 0);
    signal twoToMiSiYip_uid113_atan2Test_b : STD_LOGIC_VECTOR (21 downto 0);
    signal cstArcTan2Mi_5_uid114_atan2Test_q : STD_LOGIC_VECTOR (24 downto 0);
    signal invSignOfSelectionSignal_uid115_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_6NA_uid117_atan2Test_q : STD_LOGIC_VECTOR (29 downto 0);
    signal xip1E_6sumAHighB_uid118_atan2Test_a : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_6sumAHighB_uid118_atan2Test_b : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_6sumAHighB_uid118_atan2Test_o : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_6sumAHighB_uid118_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_6sumAHighB_uid118_atan2Test_q : STD_LOGIC_VECTOR (31 downto 0);
    signal yip1E_6NA_uid120_atan2Test_q : STD_LOGIC_VECTOR (26 downto 0);
    signal yip1E_6sumAHighB_uid121_atan2Test_a : STD_LOGIC_VECTOR (28 downto 0);
    signal yip1E_6sumAHighB_uid121_atan2Test_b : STD_LOGIC_VECTOR (28 downto 0);
    signal yip1E_6sumAHighB_uid121_atan2Test_o : STD_LOGIC_VECTOR (28 downto 0);
    signal yip1E_6sumAHighB_uid121_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_6sumAHighB_uid121_atan2Test_q : STD_LOGIC_VECTOR (27 downto 0);
    signal aip1E_6NA_uid124_atan2Test_q : STD_LOGIC_VECTOR (30 downto 0);
    signal aip1E_6sumAHighB_uid125_atan2Test_a : STD_LOGIC_VECTOR (32 downto 0);
    signal aip1E_6sumAHighB_uid125_atan2Test_b : STD_LOGIC_VECTOR (32 downto 0);
    signal aip1E_6sumAHighB_uid125_atan2Test_o : STD_LOGIC_VECTOR (32 downto 0);
    signal aip1E_6sumAHighB_uid125_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_6sumAHighB_uid125_atan2Test_q : STD_LOGIC_VECTOR (31 downto 0);
    signal xip1_6_uid126_atan2Test_in : STD_LOGIC_VECTOR (29 downto 0);
    signal xip1_6_uid126_atan2Test_b : STD_LOGIC_VECTOR (29 downto 0);
    signal yip1_6_uid127_atan2Test_in : STD_LOGIC_VECTOR (25 downto 0);
    signal yip1_6_uid127_atan2Test_b : STD_LOGIC_VECTOR (25 downto 0);
    signal aip1E_uid128_atan2Test_in : STD_LOGIC_VECTOR (30 downto 0);
    signal aip1E_uid128_atan2Test_b : STD_LOGIC_VECTOR (30 downto 0);
    signal xMSB_uid129_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal twoToMiSiXip_uid133_atan2Test_b : STD_LOGIC_VECTOR (23 downto 0);
    signal twoToMiSiYip_uid134_atan2Test_b : STD_LOGIC_VECTOR (19 downto 0);
    signal cstArcTan2Mi_6_uid135_atan2Test_q : STD_LOGIC_VECTOR (25 downto 0);
    signal invSignOfSelectionSignal_uid136_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_7_uid137_atan2Test_a : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_7_uid137_atan2Test_b : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_7_uid137_atan2Test_o : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_7_uid137_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_7_uid137_atan2Test_q : STD_LOGIC_VECTOR (31 downto 0);
    signal yip1E_7_uid138_atan2Test_a : STD_LOGIC_VECTOR (27 downto 0);
    signal yip1E_7_uid138_atan2Test_b : STD_LOGIC_VECTOR (27 downto 0);
    signal yip1E_7_uid138_atan2Test_o : STD_LOGIC_VECTOR (27 downto 0);
    signal yip1E_7_uid138_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_7_uid138_atan2Test_q : STD_LOGIC_VECTOR (26 downto 0);
    signal aip1E_7NA_uid141_atan2Test_q : STD_LOGIC_VECTOR (32 downto 0);
    signal aip1E_7sumAHighB_uid142_atan2Test_a : STD_LOGIC_VECTOR (34 downto 0);
    signal aip1E_7sumAHighB_uid142_atan2Test_b : STD_LOGIC_VECTOR (34 downto 0);
    signal aip1E_7sumAHighB_uid142_atan2Test_o : STD_LOGIC_VECTOR (34 downto 0);
    signal aip1E_7sumAHighB_uid142_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_7sumAHighB_uid142_atan2Test_q : STD_LOGIC_VECTOR (33 downto 0);
    signal xip1_7_uid143_atan2Test_in : STD_LOGIC_VECTOR (29 downto 0);
    signal xip1_7_uid143_atan2Test_b : STD_LOGIC_VECTOR (29 downto 0);
    signal yip1_7_uid144_atan2Test_in : STD_LOGIC_VECTOR (24 downto 0);
    signal yip1_7_uid144_atan2Test_b : STD_LOGIC_VECTOR (24 downto 0);
    signal aip1E_uid145_atan2Test_in : STD_LOGIC_VECTOR (32 downto 0);
    signal aip1E_uid145_atan2Test_b : STD_LOGIC_VECTOR (32 downto 0);
    signal xMSB_uid146_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal twoToMiSiXip_uid150_atan2Test_b : STD_LOGIC_VECTOR (22 downto 0);
    signal twoToMiSiYip_uid151_atan2Test_b : STD_LOGIC_VECTOR (17 downto 0);
    signal cstArcTan2Mi_7_uid152_atan2Test_q : STD_LOGIC_VECTOR (26 downto 0);
    signal invSignOfSelectionSignal_uid153_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_8_uid154_atan2Test_a : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_8_uid154_atan2Test_b : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_8_uid154_atan2Test_o : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_8_uid154_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_8_uid154_atan2Test_q : STD_LOGIC_VECTOR (31 downto 0);
    signal yip1E_8_uid155_atan2Test_a : STD_LOGIC_VECTOR (26 downto 0);
    signal yip1E_8_uid155_atan2Test_b : STD_LOGIC_VECTOR (26 downto 0);
    signal yip1E_8_uid155_atan2Test_o : STD_LOGIC_VECTOR (26 downto 0);
    signal yip1E_8_uid155_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_8_uid155_atan2Test_q : STD_LOGIC_VECTOR (25 downto 0);
    signal aip1E_8NA_uid158_atan2Test_q : STD_LOGIC_VECTOR (34 downto 0);
    signal aip1E_8sumAHighB_uid159_atan2Test_a : STD_LOGIC_VECTOR (36 downto 0);
    signal aip1E_8sumAHighB_uid159_atan2Test_b : STD_LOGIC_VECTOR (36 downto 0);
    signal aip1E_8sumAHighB_uid159_atan2Test_o : STD_LOGIC_VECTOR (36 downto 0);
    signal aip1E_8sumAHighB_uid159_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_8sumAHighB_uid159_atan2Test_q : STD_LOGIC_VECTOR (35 downto 0);
    signal xip1_8_uid160_atan2Test_in : STD_LOGIC_VECTOR (29 downto 0);
    signal xip1_8_uid160_atan2Test_b : STD_LOGIC_VECTOR (29 downto 0);
    signal yip1_8_uid161_atan2Test_in : STD_LOGIC_VECTOR (23 downto 0);
    signal yip1_8_uid161_atan2Test_b : STD_LOGIC_VECTOR (23 downto 0);
    signal aip1E_uid162_atan2Test_in : STD_LOGIC_VECTOR (34 downto 0);
    signal aip1E_uid162_atan2Test_b : STD_LOGIC_VECTOR (34 downto 0);
    signal xMSB_uid163_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal twoToMiSiXip_uid167_atan2Test_b : STD_LOGIC_VECTOR (21 downto 0);
    signal twoToMiSiYip_uid168_atan2Test_b : STD_LOGIC_VECTOR (15 downto 0);
    signal cstArcTan2Mi_8_uid169_atan2Test_q : STD_LOGIC_VECTOR (27 downto 0);
    signal invSignOfSelectionSignal_uid170_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_9_uid171_atan2Test_a : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_9_uid171_atan2Test_b : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_9_uid171_atan2Test_o : STD_LOGIC_VECTOR (32 downto 0);
    signal xip1E_9_uid171_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal xip1E_9_uid171_atan2Test_q : STD_LOGIC_VECTOR (31 downto 0);
    signal yip1E_9_uid172_atan2Test_a : STD_LOGIC_VECTOR (25 downto 0);
    signal yip1E_9_uid172_atan2Test_b : STD_LOGIC_VECTOR (25 downto 0);
    signal yip1E_9_uid172_atan2Test_o : STD_LOGIC_VECTOR (25 downto 0);
    signal yip1E_9_uid172_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_9_uid172_atan2Test_q : STD_LOGIC_VECTOR (24 downto 0);
    signal aip1E_9NA_uid175_atan2Test_q : STD_LOGIC_VECTOR (36 downto 0);
    signal aip1E_9sumAHighB_uid176_atan2Test_a : STD_LOGIC_VECTOR (38 downto 0);
    signal aip1E_9sumAHighB_uid176_atan2Test_b : STD_LOGIC_VECTOR (38 downto 0);
    signal aip1E_9sumAHighB_uid176_atan2Test_o : STD_LOGIC_VECTOR (38 downto 0);
    signal aip1E_9sumAHighB_uid176_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_9sumAHighB_uid176_atan2Test_q : STD_LOGIC_VECTOR (37 downto 0);
    signal xip1_9_uid177_atan2Test_in : STD_LOGIC_VECTOR (29 downto 0);
    signal xip1_9_uid177_atan2Test_b : STD_LOGIC_VECTOR (29 downto 0);
    signal yip1_9_uid178_atan2Test_in : STD_LOGIC_VECTOR (22 downto 0);
    signal yip1_9_uid178_atan2Test_b : STD_LOGIC_VECTOR (22 downto 0);
    signal aip1E_uid179_atan2Test_in : STD_LOGIC_VECTOR (36 downto 0);
    signal aip1E_uid179_atan2Test_b : STD_LOGIC_VECTOR (36 downto 0);
    signal xMSB_uid180_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal twoToMiSiXip_uid184_atan2Test_b : STD_LOGIC_VECTOR (20 downto 0);
    signal cstArcTan2Mi_9_uid186_atan2Test_q : STD_LOGIC_VECTOR (28 downto 0);
    signal yip1E_10_uid189_atan2Test_a : STD_LOGIC_VECTOR (24 downto 0);
    signal yip1E_10_uid189_atan2Test_b : STD_LOGIC_VECTOR (24 downto 0);
    signal yip1E_10_uid189_atan2Test_o : STD_LOGIC_VECTOR (24 downto 0);
    signal yip1E_10_uid189_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal yip1E_10_uid189_atan2Test_q : STD_LOGIC_VECTOR (23 downto 0);
    signal invSignOfSelectionSignal_uid190_atan2Test_qi : STD_LOGIC_VECTOR (0 downto 0);
    signal invSignOfSelectionSignal_uid190_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_10NA_uid192_atan2Test_q : STD_LOGIC_VECTOR (38 downto 0);
    signal aip1E_10sumAHighB_uid193_atan2Test_a : STD_LOGIC_VECTOR (40 downto 0);
    signal aip1E_10sumAHighB_uid193_atan2Test_b : STD_LOGIC_VECTOR (40 downto 0);
    signal aip1E_10sumAHighB_uid193_atan2Test_o : STD_LOGIC_VECTOR (40 downto 0);
    signal aip1E_10sumAHighB_uid193_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_10sumAHighB_uid193_atan2Test_q : STD_LOGIC_VECTOR (39 downto 0);
    signal yip1_10_uid195_atan2Test_in : STD_LOGIC_VECTOR (21 downto 0);
    signal yip1_10_uid195_atan2Test_b : STD_LOGIC_VECTOR (21 downto 0);
    signal aip1E_uid196_atan2Test_in : STD_LOGIC_VECTOR (38 downto 0);
    signal aip1E_uid196_atan2Test_b : STD_LOGIC_VECTOR (38 downto 0);
    signal xMSB_uid197_atan2Test_b : STD_LOGIC_VECTOR (0 downto 0);
    signal cstArcTan2Mi_10_uid203_atan2Test_q : STD_LOGIC_VECTOR (29 downto 0);
    signal invSignOfSelectionSignal_uid207_atan2Test_q : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_11NA_uid209_atan2Test_q : STD_LOGIC_VECTOR (40 downto 0);
    signal aip1E_11sumAHighB_uid210_atan2Test_a : STD_LOGIC_VECTOR (42 downto 0);
    signal aip1E_11sumAHighB_uid210_atan2Test_b : STD_LOGIC_VECTOR (42 downto 0);
    signal aip1E_11sumAHighB_uid210_atan2Test_o : STD_LOGIC_VECTOR (42 downto 0);
    signal aip1E_11sumAHighB_uid210_atan2Test_s : STD_LOGIC_VECTOR (0 downto 0);
    signal aip1E_11sumAHighB_uid210_atan2Test_q : STD_LOGIC_VECTOR (41 downto 0);
    signal aip1E_uid213_atan2Test_in : STD_LOGIC_VECTOR (40 downto 0);
    signal aip1E_uid213_atan2Test_b : STD_LOGIC_VECTOR (40 downto 0);
    signal alphaPreRnd_uid214_atan2Test_b : STD_LOGIC_VECTOR (11 downto 0);
    signal alphaPostRndhigh_uid220_atan2Test_a : STD_LOGIC_VECTOR (11 downto 0);
    signal alphaPostRndhigh_uid220_atan2Test_b : STD_LOGIC_VECTOR (11 downto 0);
    signal alphaPostRndhigh_uid220_atan2Test_o : STD_LOGIC_VECTOR (11 downto 0);
    signal alphaPostRndhigh_uid220_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal alphaPostRnd_uid221_atan2Test_q : STD_LOGIC_VECTOR (12 downto 0);
    signal atanRes_uid222_atan2Test_in : STD_LOGIC_VECTOR (11 downto 0);
    signal atanRes_uid222_atan2Test_b : STD_LOGIC_VECTOR (11 downto 0);
    signal cstZeroOutFormat_uid223_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal constPiP2uE_uid224_atan2Test_q : STD_LOGIC_VECTOR (10 downto 0);
    signal constPio2P2u_mergedSignalTM_uid227_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal concXZeroYZero_uid229_atan2Test_q : STD_LOGIC_VECTOR (1 downto 0);
    signal atanResPostExc_uid230_atan2Test_s : STD_LOGIC_VECTOR (1 downto 0);
    signal atanResPostExc_uid230_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal concSigns_uid231_atan2Test_q : STD_LOGIC_VECTOR (1 downto 0);
    signal constPiP2u_uid232_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal constPi_uid233_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal constantZeroOutFormat_uid234_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal constantZeroOutFormatP2u_uid235_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal firstOperand_uid237_atan2Test_s : STD_LOGIC_VECTOR (1 downto 0);
    signal firstOperand_uid237_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal secondOperand_uid238_atan2Test_s : STD_LOGIC_VECTOR (1 downto 0);
    signal secondOperand_uid238_atan2Test_q : STD_LOGIC_VECTOR (11 downto 0);
    signal outResExtended_uid239_atan2Test_a : STD_LOGIC_VECTOR (12 downto 0);
    signal outResExtended_uid239_atan2Test_b : STD_LOGIC_VECTOR (12 downto 0);
    signal outResExtended_uid239_atan2Test_o : STD_LOGIC_VECTOR (12 downto 0);
    signal outResExtended_uid239_atan2Test_q : STD_LOGIC_VECTOR (12 downto 0);
    signal atanResPostRR_uid240_atan2Test_b : STD_LOGIC_VECTOR (10 downto 0);
    signal lowRangeA_uid218_atan2Test_merged_bit_select_b : STD_LOGIC_VECTOR (0 downto 0);
    signal lowRangeA_uid218_atan2Test_merged_bit_select_c : STD_LOGIC_VECTOR (10 downto 0);
    signal redist1_alphaPreRnd_uid214_atan2Test_b_1_q : STD_LOGIC_VECTOR (11 downto 0);
    signal redist2_xMSB_uid197_atan2Test_b_1_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist3_aip1E_uid179_atan2Test_b_1_q : STD_LOGIC_VECTOR (36 downto 0);
    signal redist4_yip1_8_uid161_atan2Test_b_1_q : STD_LOGIC_VECTOR (23 downto 0);
    signal redist5_xip1_8_uid160_atan2Test_b_1_q : STD_LOGIC_VECTOR (29 downto 0);
    signal redist6_invSignOfSelectionSignal_uid153_atan2Test_q_1_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist7_aip1E_uid145_atan2Test_b_1_q : STD_LOGIC_VECTOR (32 downto 0);
    signal redist8_yip1_6_uid127_atan2Test_b_1_q : STD_LOGIC_VECTOR (25 downto 0);
    signal redist9_xip1_6_uid126_atan2Test_b_1_q : STD_LOGIC_VECTOR (29 downto 0);
    signal redist10_invSignOfSelectionSignal_uid115_atan2Test_q_1_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist11_aip1E_uid107_atan2Test_b_1_q : STD_LOGIC_VECTOR (28 downto 0);
    signal redist12_yip1_4_uid87_atan2Test_b_1_q : STD_LOGIC_VECTOR (22 downto 0);
    signal redist13_xip1_4_uid86_atan2Test_b_1_q : STD_LOGIC_VECTOR (24 downto 0);
    signal redist14_invSignOfSelectionSignal_uid75_atan2Test_q_1_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist15_aip1E_uid69_atan2Test_b_1_q : STD_LOGIC_VECTOR (24 downto 0);
    signal redist16_xNotZero_uid17_atan2Test_q_6_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist17_yNotZero_uid15_atan2Test_q_6_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist18_signY_uid8_atan2Test_b_6_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist19_signX_uid7_atan2Test_b_6_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_mem_reset0 : std_logic;
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_mem_ia : STD_LOGIC_VECTOR (10 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_mem_aa : STD_LOGIC_VECTOR (6 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_mem_ab : STD_LOGIC_VECTOR (6 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_mem_iq : STD_LOGIC_VECTOR (10 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_mem_q : STD_LOGIC_VECTOR (10 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_q : STD_LOGIC_VECTOR (6 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i : UNSIGNED (6 downto 0);
    attribute preserve : boolean;
    attribute preserve of redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i : signal is true;
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_eq : std_logic;
    attribute preserve of redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_eq : signal is true;
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_wraddr_q : STD_LOGIC_VECTOR (6 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_mem_last_q : STD_LOGIC_VECTOR (7 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_cmp_b : STD_LOGIC_VECTOR (7 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_cmp_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_cmpReg_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_notEnable_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_nor_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_sticky_ena_q : STD_LOGIC_VECTOR (0 downto 0);
    signal redist0_atanResPostRR_uid240_atan2Test_b_94_enaAnd_q : STD_LOGIC_VECTOR (0 downto 0);

begin


    -- redist0_atanResPostRR_uid240_atan2Test_b_94_notEnable(LOGICAL,268)
    redist0_atanResPostRR_uid240_atan2Test_b_94_notEnable_q <= STD_LOGIC_VECTOR(not (VCC_q));

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_nor(LOGICAL,269)
    redist0_atanResPostRR_uid240_atan2Test_b_94_nor_q <= not (redist0_atanResPostRR_uid240_atan2Test_b_94_notEnable_q or redist0_atanResPostRR_uid240_atan2Test_b_94_sticky_ena_q);

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_mem_last(CONSTANT,265)
    redist0_atanResPostRR_uid240_atan2Test_b_94_mem_last_q <= "01011011";

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_cmp(LOGICAL,266)
    redist0_atanResPostRR_uid240_atan2Test_b_94_cmp_b <= STD_LOGIC_VECTOR("0" & redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_q);
    redist0_atanResPostRR_uid240_atan2Test_b_94_cmp_q <= "1" WHEN redist0_atanResPostRR_uid240_atan2Test_b_94_mem_last_q = redist0_atanResPostRR_uid240_atan2Test_b_94_cmp_b ELSE "0";

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_cmpReg(REG,267)
    redist0_atanResPostRR_uid240_atan2Test_b_94_cmpReg_clkproc: PROCESS (clk, areset)
    BEGIN
        IF (areset = '1') THEN
            redist0_atanResPostRR_uid240_atan2Test_b_94_cmpReg_q <= "0";
        ELSIF (clk'EVENT AND clk = '1') THEN
            redist0_atanResPostRR_uid240_atan2Test_b_94_cmpReg_q <= STD_LOGIC_VECTOR(redist0_atanResPostRR_uid240_atan2Test_b_94_cmp_q);
        END IF;
    END PROCESS;

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_sticky_ena(REG,270)
    redist0_atanResPostRR_uid240_atan2Test_b_94_sticky_ena_clkproc: PROCESS (clk, areset)
    BEGIN
        IF (areset = '1') THEN
            redist0_atanResPostRR_uid240_atan2Test_b_94_sticky_ena_q <= "0";
        ELSIF (clk'EVENT AND clk = '1') THEN
            IF (redist0_atanResPostRR_uid240_atan2Test_b_94_nor_q = "1") THEN
                redist0_atanResPostRR_uid240_atan2Test_b_94_sticky_ena_q <= STD_LOGIC_VECTOR(redist0_atanResPostRR_uid240_atan2Test_b_94_cmpReg_q);
            END IF;
        END IF;
    END PROCESS;

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_enaAnd(LOGICAL,271)
    redist0_atanResPostRR_uid240_atan2Test_b_94_enaAnd_q <= redist0_atanResPostRR_uid240_atan2Test_b_94_sticky_ena_q and VCC_q;

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt(COUNTER,263)
    -- low=0, high=92, step=1, init=0
    redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_clkproc: PROCESS (clk, areset)
    BEGIN
        IF (areset = '1') THEN
            redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i <= TO_UNSIGNED(0, 7);
            redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_eq <= '0';
        ELSIF (clk'EVENT AND clk = '1') THEN
            IF (redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i = TO_UNSIGNED(91, 7)) THEN
                redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_eq <= '1';
            ELSE
                redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_eq <= '0';
            END IF;
            IF (redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_eq = '1') THEN
                redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i <= redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i + 36;
            ELSE
                redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i <= redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i + 1;
            END IF;
        END IF;
    END PROCESS;
    redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_q <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR(RESIZE(redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_i, 7)));

    -- constPi_uid233_atan2Test(CONSTANT,232)
    constPi_uid233_atan2Test_q <= "110010010001";

    -- GND(CONSTANT,0)
    GND_q <= "0";

    -- constPiP2uE_uid224_atan2Test(CONSTANT,223)
    constPiP2uE_uid224_atan2Test_q <= "11001001010";

    -- constPio2P2u_mergedSignalTM_uid227_atan2Test(BITJOIN,226)@6
    constPio2P2u_mergedSignalTM_uid227_atan2Test_q <= GND_q & constPiP2uE_uid224_atan2Test_q;

    -- cstZeroOutFormat_uid223_atan2Test(CONSTANT,222)
    cstZeroOutFormat_uid223_atan2Test_q <= "000000000010";

    -- alphaPostRndhigh_uid220_atan2Test(ADD,219)@6
    alphaPostRndhigh_uid220_atan2Test_a <= STD_LOGIC_VECTOR("0" & lowRangeA_uid218_atan2Test_merged_bit_select_c);
    alphaPostRndhigh_uid220_atan2Test_b <= STD_LOGIC_VECTOR("00000000000" & VCC_q);
    alphaPostRndhigh_uid220_atan2Test_o <= STD_LOGIC_VECTOR(UNSIGNED(alphaPostRndhigh_uid220_atan2Test_a) + UNSIGNED(alphaPostRndhigh_uid220_atan2Test_b));
    alphaPostRndhigh_uid220_atan2Test_q <= alphaPostRndhigh_uid220_atan2Test_o(11 downto 0);

    -- xMSB_uid180_atan2Test(BITSELECT,179)@4
    xMSB_uid180_atan2Test_b <= STD_LOGIC_VECTOR(yip1_9_uid178_atan2Test_b(22 downto 22));

    -- xMSB_uid146_atan2Test(BITSELECT,145)@3
    xMSB_uid146_atan2Test_b <= STD_LOGIC_VECTOR(yip1_7_uid144_atan2Test_b(24 downto 24));

    -- signX_uid7_atan2Test(BITSELECT,6)@0
    signX_uid7_atan2Test_b <= STD_LOGIC_VECTOR(x(17 downto 17));

    -- invSignX_uid9_atan2Test(LOGICAL,8)@0
    invSignX_uid9_atan2Test_q <= not (signX_uid7_atan2Test_b);

    -- constantZero_uid6_atan2Test(CONSTANT,5)
    constantZero_uid6_atan2Test_q <= "000000000000000000";

    -- absXE_uid10_atan2Test(ADDSUB,9)@0
    absXE_uid10_atan2Test_s <= invSignX_uid9_atan2Test_q;
    absXE_uid10_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((19 downto 18 => constantZero_uid6_atan2Test_q(17)) & constantZero_uid6_atan2Test_q));
    absXE_uid10_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((19 downto 18 => x(17)) & x));
    absXE_uid10_atan2Test_combproc: PROCESS (absXE_uid10_atan2Test_a, absXE_uid10_atan2Test_b, absXE_uid10_atan2Test_s)
    BEGIN
        IF (absXE_uid10_atan2Test_s = "1") THEN
            absXE_uid10_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(absXE_uid10_atan2Test_a) + SIGNED(absXE_uid10_atan2Test_b));
        ELSE
            absXE_uid10_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(absXE_uid10_atan2Test_a) - SIGNED(absXE_uid10_atan2Test_b));
        END IF;
    END PROCESS;
    absXE_uid10_atan2Test_q <= absXE_uid10_atan2Test_o(18 downto 0);

    -- absX_uid13_atan2Test(BITSELECT,12)@0
    absX_uid13_atan2Test_in <= absXE_uid10_atan2Test_q(17 downto 0);
    absX_uid13_atan2Test_b <= absX_uid13_atan2Test_in(17 downto 0);

    -- signY_uid8_atan2Test(BITSELECT,7)@0
    signY_uid8_atan2Test_b <= STD_LOGIC_VECTOR(y(17 downto 17));

    -- invSignY_uid11_atan2Test(LOGICAL,10)@0
    invSignY_uid11_atan2Test_q <= not (signY_uid8_atan2Test_b);

    -- absYE_uid12_atan2Test(ADDSUB,11)@0
    absYE_uid12_atan2Test_s <= invSignY_uid11_atan2Test_q;
    absYE_uid12_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((19 downto 18 => constantZero_uid6_atan2Test_q(17)) & constantZero_uid6_atan2Test_q));
    absYE_uid12_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((19 downto 18 => y(17)) & y));
    absYE_uid12_atan2Test_combproc: PROCESS (absYE_uid12_atan2Test_a, absYE_uid12_atan2Test_b, absYE_uid12_atan2Test_s)
    BEGIN
        IF (absYE_uid12_atan2Test_s = "1") THEN
            absYE_uid12_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(absYE_uid12_atan2Test_a) + SIGNED(absYE_uid12_atan2Test_b));
        ELSE
            absYE_uid12_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(absYE_uid12_atan2Test_a) - SIGNED(absYE_uid12_atan2Test_b));
        END IF;
    END PROCESS;
    absYE_uid12_atan2Test_q <= absYE_uid12_atan2Test_o(18 downto 0);

    -- absY_uid14_atan2Test(BITSELECT,13)@0
    absY_uid14_atan2Test_in <= absYE_uid12_atan2Test_q(17 downto 0);
    absY_uid14_atan2Test_b <= absY_uid14_atan2Test_in(17 downto 0);

    -- yip1E_1_uid24_atan2Test(SUB,23)@0 + 1
    yip1E_1_uid24_atan2Test_a <= STD_LOGIC_VECTOR("0" & absY_uid14_atan2Test_b);
    yip1E_1_uid24_atan2Test_b <= STD_LOGIC_VECTOR("0" & absX_uid13_atan2Test_b);
    yip1E_1_uid24_atan2Test_clkproc: PROCESS (clk, areset)
    BEGIN
        IF (areset = '1') THEN
            yip1E_1_uid24_atan2Test_o <= (others => '0');
        ELSIF (clk'EVENT AND clk = '1') THEN
            yip1E_1_uid24_atan2Test_o <= STD_LOGIC_VECTOR(UNSIGNED(yip1E_1_uid24_atan2Test_a) - UNSIGNED(yip1E_1_uid24_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_1_uid24_atan2Test_q <= yip1E_1_uid24_atan2Test_o(18 downto 0);

    -- xMSB_uid32_atan2Test(BITSELECT,31)@1
    xMSB_uid32_atan2Test_b <= STD_LOGIC_VECTOR(yip1E_1_uid24_atan2Test_q(18 downto 18));

    -- xip1E_1_uid23_atan2Test(ADD,22)@0 + 1
    xip1E_1_uid23_atan2Test_a <= STD_LOGIC_VECTOR("0" & absX_uid13_atan2Test_b);
    xip1E_1_uid23_atan2Test_b <= STD_LOGIC_VECTOR("0" & absY_uid14_atan2Test_b);
    xip1E_1_uid23_atan2Test_clkproc: PROCESS (clk, areset)
    BEGIN
        IF (areset = '1') THEN
            xip1E_1_uid23_atan2Test_o <= (others => '0');
        ELSIF (clk'EVENT AND clk = '1') THEN
            xip1E_1_uid23_atan2Test_o <= STD_LOGIC_VECTOR(UNSIGNED(xip1E_1_uid23_atan2Test_a) + UNSIGNED(xip1E_1_uid23_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_1_uid23_atan2Test_q <= xip1E_1_uid23_atan2Test_o(18 downto 0);

    -- yip1E_2NA_uid42_atan2Test(BITJOIN,41)@1
    yip1E_2NA_uid42_atan2Test_q <= yip1E_1_uid24_atan2Test_q & GND_q;

    -- yip1E_2sumAHighB_uid43_atan2Test(ADDSUB,42)@1
    yip1E_2sumAHighB_uid43_atan2Test_s <= xMSB_uid32_atan2Test_b;
    yip1E_2sumAHighB_uid43_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((21 downto 20 => yip1E_2NA_uid42_atan2Test_q(19)) & yip1E_2NA_uid42_atan2Test_q));
    yip1E_2sumAHighB_uid43_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & xip1E_1_uid23_atan2Test_q));
    yip1E_2sumAHighB_uid43_atan2Test_combproc: PROCESS (yip1E_2sumAHighB_uid43_atan2Test_a, yip1E_2sumAHighB_uid43_atan2Test_b, yip1E_2sumAHighB_uid43_atan2Test_s)
    BEGIN
        IF (yip1E_2sumAHighB_uid43_atan2Test_s = "1") THEN
            yip1E_2sumAHighB_uid43_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_2sumAHighB_uid43_atan2Test_a) + SIGNED(yip1E_2sumAHighB_uid43_atan2Test_b));
        ELSE
            yip1E_2sumAHighB_uid43_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_2sumAHighB_uid43_atan2Test_a) - SIGNED(yip1E_2sumAHighB_uid43_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_2sumAHighB_uid43_atan2Test_q <= yip1E_2sumAHighB_uid43_atan2Test_o(20 downto 0);

    -- yip1_2_uid49_atan2Test(BITSELECT,48)@1
    yip1_2_uid49_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_2sumAHighB_uid43_atan2Test_q(19 downto 0));
    yip1_2_uid49_atan2Test_b <= STD_LOGIC_VECTOR(yip1_2_uid49_atan2Test_in(19 downto 0));

    -- xMSB_uid51_atan2Test(BITSELECT,50)@1
    xMSB_uid51_atan2Test_b <= STD_LOGIC_VECTOR(yip1_2_uid49_atan2Test_b(19 downto 19));

    -- invSignOfSelectionSignal_uid37_atan2Test(LOGICAL,36)@1
    invSignOfSelectionSignal_uid37_atan2Test_q <= not (xMSB_uid32_atan2Test_b);

    -- xip1E_2NA_uid39_atan2Test(BITJOIN,38)@1
    xip1E_2NA_uid39_atan2Test_q <= xip1E_1_uid23_atan2Test_q & GND_q;

    -- xip1E_2sumAHighB_uid40_atan2Test(ADDSUB,39)@1
    xip1E_2sumAHighB_uid40_atan2Test_s <= invSignOfSelectionSignal_uid37_atan2Test_q;
    xip1E_2sumAHighB_uid40_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & xip1E_2NA_uid39_atan2Test_q));
    xip1E_2sumAHighB_uid40_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((22 downto 19 => yip1E_1_uid24_atan2Test_q(18)) & yip1E_1_uid24_atan2Test_q));
    xip1E_2sumAHighB_uid40_atan2Test_combproc: PROCESS (xip1E_2sumAHighB_uid40_atan2Test_a, xip1E_2sumAHighB_uid40_atan2Test_b, xip1E_2sumAHighB_uid40_atan2Test_s)
    BEGIN
        IF (xip1E_2sumAHighB_uid40_atan2Test_s = "1") THEN
            xip1E_2sumAHighB_uid40_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_2sumAHighB_uid40_atan2Test_a) + SIGNED(xip1E_2sumAHighB_uid40_atan2Test_b));
        ELSE
            xip1E_2sumAHighB_uid40_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_2sumAHighB_uid40_atan2Test_a) - SIGNED(xip1E_2sumAHighB_uid40_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_2sumAHighB_uid40_atan2Test_q <= xip1E_2sumAHighB_uid40_atan2Test_o(21 downto 0);

    -- xip1_2_uid48_atan2Test(BITSELECT,47)@1
    xip1_2_uid48_atan2Test_in <= xip1E_2sumAHighB_uid40_atan2Test_q(19 downto 0);
    xip1_2_uid48_atan2Test_b <= xip1_2_uid48_atan2Test_in(19 downto 0);

    -- aip1E_2CostZeroPaddingA_uid45_atan2Test(CONSTANT,44)
    aip1E_2CostZeroPaddingA_uid45_atan2Test_q <= "00";

    -- yip1E_3NA_uid61_atan2Test(BITJOIN,60)@1
    yip1E_3NA_uid61_atan2Test_q <= yip1_2_uid49_atan2Test_b & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- yip1E_3sumAHighB_uid62_atan2Test(ADDSUB,61)@1
    yip1E_3sumAHighB_uid62_atan2Test_s <= xMSB_uid51_atan2Test_b;
    yip1E_3sumAHighB_uid62_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((23 downto 22 => yip1E_3NA_uid61_atan2Test_q(21)) & yip1E_3NA_uid61_atan2Test_q));
    yip1E_3sumAHighB_uid62_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("0000" & xip1_2_uid48_atan2Test_b));
    yip1E_3sumAHighB_uid62_atan2Test_combproc: PROCESS (yip1E_3sumAHighB_uid62_atan2Test_a, yip1E_3sumAHighB_uid62_atan2Test_b, yip1E_3sumAHighB_uid62_atan2Test_s)
    BEGIN
        IF (yip1E_3sumAHighB_uid62_atan2Test_s = "1") THEN
            yip1E_3sumAHighB_uid62_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_3sumAHighB_uid62_atan2Test_a) + SIGNED(yip1E_3sumAHighB_uid62_atan2Test_b));
        ELSE
            yip1E_3sumAHighB_uid62_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_3sumAHighB_uid62_atan2Test_a) - SIGNED(yip1E_3sumAHighB_uid62_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_3sumAHighB_uid62_atan2Test_q <= yip1E_3sumAHighB_uid62_atan2Test_o(22 downto 0);

    -- yip1_3_uid68_atan2Test(BITSELECT,67)@1
    yip1_3_uid68_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_3sumAHighB_uid62_atan2Test_q(20 downto 0));
    yip1_3_uid68_atan2Test_b <= STD_LOGIC_VECTOR(yip1_3_uid68_atan2Test_in(20 downto 0));

    -- xMSB_uid70_atan2Test(BITSELECT,69)@1
    xMSB_uid70_atan2Test_b <= STD_LOGIC_VECTOR(yip1_3_uid68_atan2Test_b(20 downto 20));

    -- invSignOfSelectionSignal_uid56_atan2Test(LOGICAL,55)@1
    invSignOfSelectionSignal_uid56_atan2Test_q <= not (xMSB_uid51_atan2Test_b);

    -- xip1E_3NA_uid58_atan2Test(BITJOIN,57)@1
    xip1E_3NA_uid58_atan2Test_q <= xip1_2_uid48_atan2Test_b & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- xip1E_3sumAHighB_uid59_atan2Test(ADDSUB,58)@1
    xip1E_3sumAHighB_uid59_atan2Test_s <= invSignOfSelectionSignal_uid56_atan2Test_q;
    xip1E_3sumAHighB_uid59_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & xip1E_3NA_uid58_atan2Test_q));
    xip1E_3sumAHighB_uid59_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((24 downto 20 => yip1_2_uid49_atan2Test_b(19)) & yip1_2_uid49_atan2Test_b));
    xip1E_3sumAHighB_uid59_atan2Test_combproc: PROCESS (xip1E_3sumAHighB_uid59_atan2Test_a, xip1E_3sumAHighB_uid59_atan2Test_b, xip1E_3sumAHighB_uid59_atan2Test_s)
    BEGIN
        IF (xip1E_3sumAHighB_uid59_atan2Test_s = "1") THEN
            xip1E_3sumAHighB_uid59_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_3sumAHighB_uid59_atan2Test_a) + SIGNED(xip1E_3sumAHighB_uid59_atan2Test_b));
        ELSE
            xip1E_3sumAHighB_uid59_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_3sumAHighB_uid59_atan2Test_a) - SIGNED(xip1E_3sumAHighB_uid59_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_3sumAHighB_uid59_atan2Test_q <= xip1E_3sumAHighB_uid59_atan2Test_o(23 downto 0);

    -- xip1_3_uid67_atan2Test(BITSELECT,66)@1
    xip1_3_uid67_atan2Test_in <= xip1E_3sumAHighB_uid59_atan2Test_q(21 downto 0);
    xip1_3_uid67_atan2Test_b <= xip1_3_uid67_atan2Test_in(21 downto 0);

    -- xip1E_4CostZeroPaddingA_uid76_atan2Test(CONSTANT,75)
    xip1E_4CostZeroPaddingA_uid76_atan2Test_q <= "000";

    -- yip1E_4NA_uid80_atan2Test(BITJOIN,79)@1
    yip1E_4NA_uid80_atan2Test_q <= yip1_3_uid68_atan2Test_b & xip1E_4CostZeroPaddingA_uid76_atan2Test_q;

    -- yip1E_4sumAHighB_uid81_atan2Test(ADDSUB,80)@1
    yip1E_4sumAHighB_uid81_atan2Test_s <= xMSB_uid70_atan2Test_b;
    yip1E_4sumAHighB_uid81_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((25 downto 24 => yip1E_4NA_uid80_atan2Test_q(23)) & yip1E_4NA_uid80_atan2Test_q));
    yip1E_4sumAHighB_uid81_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("0000" & xip1_3_uid67_atan2Test_b));
    yip1E_4sumAHighB_uid81_atan2Test_combproc: PROCESS (yip1E_4sumAHighB_uid81_atan2Test_a, yip1E_4sumAHighB_uid81_atan2Test_b, yip1E_4sumAHighB_uid81_atan2Test_s)
    BEGIN
        IF (yip1E_4sumAHighB_uid81_atan2Test_s = "1") THEN
            yip1E_4sumAHighB_uid81_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_4sumAHighB_uid81_atan2Test_a) + SIGNED(yip1E_4sumAHighB_uid81_atan2Test_b));
        ELSE
            yip1E_4sumAHighB_uid81_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_4sumAHighB_uid81_atan2Test_a) - SIGNED(yip1E_4sumAHighB_uid81_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_4sumAHighB_uid81_atan2Test_q <= yip1E_4sumAHighB_uid81_atan2Test_o(24 downto 0);

    -- yip1_4_uid87_atan2Test(BITSELECT,86)@1
    yip1_4_uid87_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_4sumAHighB_uid81_atan2Test_q(22 downto 0));
    yip1_4_uid87_atan2Test_b <= STD_LOGIC_VECTOR(yip1_4_uid87_atan2Test_in(22 downto 0));

    -- redist12_yip1_4_uid87_atan2Test_b_1(DELAY,254)
    redist12_yip1_4_uid87_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 23, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => yip1_4_uid87_atan2Test_b, xout => redist12_yip1_4_uid87_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- xMSB_uid89_atan2Test(BITSELECT,88)@2
    xMSB_uid89_atan2Test_b <= STD_LOGIC_VECTOR(redist12_yip1_4_uid87_atan2Test_b_1_q(22 downto 22));

    -- invSignOfSelectionSignal_uid75_atan2Test(LOGICAL,74)@1
    invSignOfSelectionSignal_uid75_atan2Test_q <= not (xMSB_uid70_atan2Test_b);

    -- xip1E_4NA_uid77_atan2Test(BITJOIN,76)@1
    xip1E_4NA_uid77_atan2Test_q <= xip1_3_uid67_atan2Test_b & xip1E_4CostZeroPaddingA_uid76_atan2Test_q;

    -- xip1E_4sumAHighB_uid78_atan2Test(ADDSUB,77)@1
    xip1E_4sumAHighB_uid78_atan2Test_s <= invSignOfSelectionSignal_uid75_atan2Test_q;
    xip1E_4sumAHighB_uid78_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & xip1E_4NA_uid77_atan2Test_q));
    xip1E_4sumAHighB_uid78_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((27 downto 21 => yip1_3_uid68_atan2Test_b(20)) & yip1_3_uid68_atan2Test_b));
    xip1E_4sumAHighB_uid78_atan2Test_combproc: PROCESS (xip1E_4sumAHighB_uid78_atan2Test_a, xip1E_4sumAHighB_uid78_atan2Test_b, xip1E_4sumAHighB_uid78_atan2Test_s)
    BEGIN
        IF (xip1E_4sumAHighB_uid78_atan2Test_s = "1") THEN
            xip1E_4sumAHighB_uid78_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_4sumAHighB_uid78_atan2Test_a) + SIGNED(xip1E_4sumAHighB_uid78_atan2Test_b));
        ELSE
            xip1E_4sumAHighB_uid78_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_4sumAHighB_uid78_atan2Test_a) - SIGNED(xip1E_4sumAHighB_uid78_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_4sumAHighB_uid78_atan2Test_q <= xip1E_4sumAHighB_uid78_atan2Test_o(26 downto 0);

    -- xip1_4_uid86_atan2Test(BITSELECT,85)@1
    xip1_4_uid86_atan2Test_in <= xip1E_4sumAHighB_uid78_atan2Test_q(24 downto 0);
    xip1_4_uid86_atan2Test_b <= xip1_4_uid86_atan2Test_in(24 downto 0);

    -- redist13_xip1_4_uid86_atan2Test_b_1(DELAY,255)
    redist13_xip1_4_uid86_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 25, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => xip1_4_uid86_atan2Test_b, xout => redist13_xip1_4_uid86_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- xip1E_5CostZeroPaddingA_uid95_atan2Test(CONSTANT,94)
    xip1E_5CostZeroPaddingA_uid95_atan2Test_q <= "0000";

    -- yip1E_5NA_uid99_atan2Test(BITJOIN,98)@2
    yip1E_5NA_uid99_atan2Test_q <= redist12_yip1_4_uid87_atan2Test_b_1_q & xip1E_5CostZeroPaddingA_uid95_atan2Test_q;

    -- yip1E_5sumAHighB_uid100_atan2Test(ADDSUB,99)@2
    yip1E_5sumAHighB_uid100_atan2Test_s <= xMSB_uid89_atan2Test_b;
    yip1E_5sumAHighB_uid100_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((28 downto 27 => yip1E_5NA_uid99_atan2Test_q(26)) & yip1E_5NA_uid99_atan2Test_q));
    yip1E_5sumAHighB_uid100_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("0000" & redist13_xip1_4_uid86_atan2Test_b_1_q));
    yip1E_5sumAHighB_uid100_atan2Test_combproc: PROCESS (yip1E_5sumAHighB_uid100_atan2Test_a, yip1E_5sumAHighB_uid100_atan2Test_b, yip1E_5sumAHighB_uid100_atan2Test_s)
    BEGIN
        IF (yip1E_5sumAHighB_uid100_atan2Test_s = "1") THEN
            yip1E_5sumAHighB_uid100_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_5sumAHighB_uid100_atan2Test_a) + SIGNED(yip1E_5sumAHighB_uid100_atan2Test_b));
        ELSE
            yip1E_5sumAHighB_uid100_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_5sumAHighB_uid100_atan2Test_a) - SIGNED(yip1E_5sumAHighB_uid100_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_5sumAHighB_uid100_atan2Test_q <= yip1E_5sumAHighB_uid100_atan2Test_o(27 downto 0);

    -- yip1_5_uid106_atan2Test(BITSELECT,105)@2
    yip1_5_uid106_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_5sumAHighB_uid100_atan2Test_q(25 downto 0));
    yip1_5_uid106_atan2Test_b <= STD_LOGIC_VECTOR(yip1_5_uid106_atan2Test_in(25 downto 0));

    -- xMSB_uid108_atan2Test(BITSELECT,107)@2
    xMSB_uid108_atan2Test_b <= STD_LOGIC_VECTOR(yip1_5_uid106_atan2Test_b(25 downto 25));

    -- invSignOfSelectionSignal_uid94_atan2Test(LOGICAL,93)@2
    invSignOfSelectionSignal_uid94_atan2Test_q <= not (xMSB_uid89_atan2Test_b);

    -- xip1E_5NA_uid96_atan2Test(BITJOIN,95)@2
    xip1E_5NA_uid96_atan2Test_q <= redist13_xip1_4_uid86_atan2Test_b_1_q & xip1E_5CostZeroPaddingA_uid95_atan2Test_q;

    -- xip1E_5sumAHighB_uid97_atan2Test(ADDSUB,96)@2
    xip1E_5sumAHighB_uid97_atan2Test_s <= invSignOfSelectionSignal_uid94_atan2Test_q;
    xip1E_5sumAHighB_uid97_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & xip1E_5NA_uid96_atan2Test_q));
    xip1E_5sumAHighB_uid97_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((31 downto 23 => redist12_yip1_4_uid87_atan2Test_b_1_q(22)) & redist12_yip1_4_uid87_atan2Test_b_1_q));
    xip1E_5sumAHighB_uid97_atan2Test_combproc: PROCESS (xip1E_5sumAHighB_uid97_atan2Test_a, xip1E_5sumAHighB_uid97_atan2Test_b, xip1E_5sumAHighB_uid97_atan2Test_s)
    BEGIN
        IF (xip1E_5sumAHighB_uid97_atan2Test_s = "1") THEN
            xip1E_5sumAHighB_uid97_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_5sumAHighB_uid97_atan2Test_a) + SIGNED(xip1E_5sumAHighB_uid97_atan2Test_b));
        ELSE
            xip1E_5sumAHighB_uid97_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_5sumAHighB_uid97_atan2Test_a) - SIGNED(xip1E_5sumAHighB_uid97_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_5sumAHighB_uid97_atan2Test_q <= xip1E_5sumAHighB_uid97_atan2Test_o(30 downto 0);

    -- xip1_5_uid105_atan2Test(BITSELECT,104)@2
    xip1_5_uid105_atan2Test_in <= xip1E_5sumAHighB_uid97_atan2Test_q(28 downto 0);
    xip1_5_uid105_atan2Test_b <= xip1_5_uid105_atan2Test_in(28 downto 0);

    -- twoToMiSiXip_uid112_atan2Test(BITSELECT,111)@2
    twoToMiSiXip_uid112_atan2Test_b <= xip1_5_uid105_atan2Test_b(28 downto 4);

    -- yip1E_6NA_uid120_atan2Test(BITJOIN,119)@2
    yip1E_6NA_uid120_atan2Test_q <= yip1_5_uid106_atan2Test_b & GND_q;

    -- yip1E_6sumAHighB_uid121_atan2Test(ADDSUB,120)@2
    yip1E_6sumAHighB_uid121_atan2Test_s <= xMSB_uid108_atan2Test_b;
    yip1E_6sumAHighB_uid121_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((28 downto 27 => yip1E_6NA_uid120_atan2Test_q(26)) & yip1E_6NA_uid120_atan2Test_q));
    yip1E_6sumAHighB_uid121_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("0000" & twoToMiSiXip_uid112_atan2Test_b));
    yip1E_6sumAHighB_uid121_atan2Test_combproc: PROCESS (yip1E_6sumAHighB_uid121_atan2Test_a, yip1E_6sumAHighB_uid121_atan2Test_b, yip1E_6sumAHighB_uid121_atan2Test_s)
    BEGIN
        IF (yip1E_6sumAHighB_uid121_atan2Test_s = "1") THEN
            yip1E_6sumAHighB_uid121_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_6sumAHighB_uid121_atan2Test_a) + SIGNED(yip1E_6sumAHighB_uid121_atan2Test_b));
        ELSE
            yip1E_6sumAHighB_uid121_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_6sumAHighB_uid121_atan2Test_a) - SIGNED(yip1E_6sumAHighB_uid121_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_6sumAHighB_uid121_atan2Test_q <= yip1E_6sumAHighB_uid121_atan2Test_o(27 downto 0);

    -- yip1_6_uid127_atan2Test(BITSELECT,126)@2
    yip1_6_uid127_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_6sumAHighB_uid121_atan2Test_q(25 downto 0));
    yip1_6_uid127_atan2Test_b <= STD_LOGIC_VECTOR(yip1_6_uid127_atan2Test_in(25 downto 0));

    -- redist8_yip1_6_uid127_atan2Test_b_1(DELAY,250)
    redist8_yip1_6_uid127_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 26, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => yip1_6_uid127_atan2Test_b, xout => redist8_yip1_6_uid127_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- xMSB_uid129_atan2Test(BITSELECT,128)@3
    xMSB_uid129_atan2Test_b <= STD_LOGIC_VECTOR(redist8_yip1_6_uid127_atan2Test_b_1_q(25 downto 25));

    -- invSignOfSelectionSignal_uid136_atan2Test(LOGICAL,135)@3
    invSignOfSelectionSignal_uid136_atan2Test_q <= not (xMSB_uid129_atan2Test_b);

    -- twoToMiSiYip_uid134_atan2Test(BITSELECT,133)@3
    twoToMiSiYip_uid134_atan2Test_b <= STD_LOGIC_VECTOR(redist8_yip1_6_uid127_atan2Test_b_1_q(25 downto 6));

    -- invSignOfSelectionSignal_uid115_atan2Test(LOGICAL,114)@2
    invSignOfSelectionSignal_uid115_atan2Test_q <= not (xMSB_uid108_atan2Test_b);

    -- twoToMiSiYip_uid113_atan2Test(BITSELECT,112)@2
    twoToMiSiYip_uid113_atan2Test_b <= STD_LOGIC_VECTOR(yip1_5_uid106_atan2Test_b(25 downto 4));

    -- xip1E_6NA_uid117_atan2Test(BITJOIN,116)@2
    xip1E_6NA_uid117_atan2Test_q <= xip1_5_uid105_atan2Test_b & GND_q;

    -- xip1E_6sumAHighB_uid118_atan2Test(ADDSUB,117)@2
    xip1E_6sumAHighB_uid118_atan2Test_s <= invSignOfSelectionSignal_uid115_atan2Test_q;
    xip1E_6sumAHighB_uid118_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & xip1E_6NA_uid117_atan2Test_q));
    xip1E_6sumAHighB_uid118_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((32 downto 22 => twoToMiSiYip_uid113_atan2Test_b(21)) & twoToMiSiYip_uid113_atan2Test_b));
    xip1E_6sumAHighB_uid118_atan2Test_combproc: PROCESS (xip1E_6sumAHighB_uid118_atan2Test_a, xip1E_6sumAHighB_uid118_atan2Test_b, xip1E_6sumAHighB_uid118_atan2Test_s)
    BEGIN
        IF (xip1E_6sumAHighB_uid118_atan2Test_s = "1") THEN
            xip1E_6sumAHighB_uid118_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_6sumAHighB_uid118_atan2Test_a) + SIGNED(xip1E_6sumAHighB_uid118_atan2Test_b));
        ELSE
            xip1E_6sumAHighB_uid118_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_6sumAHighB_uid118_atan2Test_a) - SIGNED(xip1E_6sumAHighB_uid118_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_6sumAHighB_uid118_atan2Test_q <= xip1E_6sumAHighB_uid118_atan2Test_o(31 downto 0);

    -- xip1_6_uid126_atan2Test(BITSELECT,125)@2
    xip1_6_uid126_atan2Test_in <= xip1E_6sumAHighB_uid118_atan2Test_q(29 downto 0);
    xip1_6_uid126_atan2Test_b <= xip1_6_uid126_atan2Test_in(29 downto 0);

    -- redist9_xip1_6_uid126_atan2Test_b_1(DELAY,251)
    redist9_xip1_6_uid126_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 30, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => xip1_6_uid126_atan2Test_b, xout => redist9_xip1_6_uid126_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- xip1E_7_uid137_atan2Test(ADDSUB,136)@3
    xip1E_7_uid137_atan2Test_s <= invSignOfSelectionSignal_uid136_atan2Test_q;
    xip1E_7_uid137_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & redist9_xip1_6_uid126_atan2Test_b_1_q));
    xip1E_7_uid137_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((32 downto 20 => twoToMiSiYip_uid134_atan2Test_b(19)) & twoToMiSiYip_uid134_atan2Test_b));
    xip1E_7_uid137_atan2Test_combproc: PROCESS (xip1E_7_uid137_atan2Test_a, xip1E_7_uid137_atan2Test_b, xip1E_7_uid137_atan2Test_s)
    BEGIN
        IF (xip1E_7_uid137_atan2Test_s = "1") THEN
            xip1E_7_uid137_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_7_uid137_atan2Test_a) + SIGNED(xip1E_7_uid137_atan2Test_b));
        ELSE
            xip1E_7_uid137_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_7_uid137_atan2Test_a) - SIGNED(xip1E_7_uid137_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_7_uid137_atan2Test_q <= xip1E_7_uid137_atan2Test_o(31 downto 0);

    -- xip1_7_uid143_atan2Test(BITSELECT,142)@3
    xip1_7_uid143_atan2Test_in <= xip1E_7_uid137_atan2Test_q(29 downto 0);
    xip1_7_uid143_atan2Test_b <= xip1_7_uid143_atan2Test_in(29 downto 0);

    -- twoToMiSiXip_uid150_atan2Test(BITSELECT,149)@3
    twoToMiSiXip_uid150_atan2Test_b <= xip1_7_uid143_atan2Test_b(29 downto 7);

    -- twoToMiSiXip_uid133_atan2Test(BITSELECT,132)@3
    twoToMiSiXip_uid133_atan2Test_b <= redist9_xip1_6_uid126_atan2Test_b_1_q(29 downto 6);

    -- yip1E_7_uid138_atan2Test(ADDSUB,137)@3
    yip1E_7_uid138_atan2Test_s <= xMSB_uid129_atan2Test_b;
    yip1E_7_uid138_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((27 downto 26 => redist8_yip1_6_uid127_atan2Test_b_1_q(25)) & redist8_yip1_6_uid127_atan2Test_b_1_q));
    yip1E_7_uid138_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("0000" & twoToMiSiXip_uid133_atan2Test_b));
    yip1E_7_uid138_atan2Test_combproc: PROCESS (yip1E_7_uid138_atan2Test_a, yip1E_7_uid138_atan2Test_b, yip1E_7_uid138_atan2Test_s)
    BEGIN
        IF (yip1E_7_uid138_atan2Test_s = "1") THEN
            yip1E_7_uid138_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_7_uid138_atan2Test_a) + SIGNED(yip1E_7_uid138_atan2Test_b));
        ELSE
            yip1E_7_uid138_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_7_uid138_atan2Test_a) - SIGNED(yip1E_7_uid138_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_7_uid138_atan2Test_q <= yip1E_7_uid138_atan2Test_o(26 downto 0);

    -- yip1_7_uid144_atan2Test(BITSELECT,143)@3
    yip1_7_uid144_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_7_uid138_atan2Test_q(24 downto 0));
    yip1_7_uid144_atan2Test_b <= STD_LOGIC_VECTOR(yip1_7_uid144_atan2Test_in(24 downto 0));

    -- yip1E_8_uid155_atan2Test(ADDSUB,154)@3
    yip1E_8_uid155_atan2Test_s <= xMSB_uid146_atan2Test_b;
    yip1E_8_uid155_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((26 downto 25 => yip1_7_uid144_atan2Test_b(24)) & yip1_7_uid144_atan2Test_b));
    yip1E_8_uid155_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("0000" & twoToMiSiXip_uid150_atan2Test_b));
    yip1E_8_uid155_atan2Test_combproc: PROCESS (yip1E_8_uid155_atan2Test_a, yip1E_8_uid155_atan2Test_b, yip1E_8_uid155_atan2Test_s)
    BEGIN
        IF (yip1E_8_uid155_atan2Test_s = "1") THEN
            yip1E_8_uid155_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_8_uid155_atan2Test_a) + SIGNED(yip1E_8_uid155_atan2Test_b));
        ELSE
            yip1E_8_uid155_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_8_uid155_atan2Test_a) - SIGNED(yip1E_8_uid155_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_8_uid155_atan2Test_q <= yip1E_8_uid155_atan2Test_o(25 downto 0);

    -- yip1_8_uid161_atan2Test(BITSELECT,160)@3
    yip1_8_uid161_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_8_uid155_atan2Test_q(23 downto 0));
    yip1_8_uid161_atan2Test_b <= STD_LOGIC_VECTOR(yip1_8_uid161_atan2Test_in(23 downto 0));

    -- redist4_yip1_8_uid161_atan2Test_b_1(DELAY,246)
    redist4_yip1_8_uid161_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 24, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => yip1_8_uid161_atan2Test_b, xout => redist4_yip1_8_uid161_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- xMSB_uid163_atan2Test(BITSELECT,162)@4
    xMSB_uid163_atan2Test_b <= STD_LOGIC_VECTOR(redist4_yip1_8_uid161_atan2Test_b_1_q(23 downto 23));

    -- invSignOfSelectionSignal_uid170_atan2Test(LOGICAL,169)@4
    invSignOfSelectionSignal_uid170_atan2Test_q <= not (xMSB_uid163_atan2Test_b);

    -- twoToMiSiYip_uid168_atan2Test(BITSELECT,167)@4
    twoToMiSiYip_uid168_atan2Test_b <= STD_LOGIC_VECTOR(redist4_yip1_8_uid161_atan2Test_b_1_q(23 downto 8));

    -- invSignOfSelectionSignal_uid153_atan2Test(LOGICAL,152)@3
    invSignOfSelectionSignal_uid153_atan2Test_q <= not (xMSB_uid146_atan2Test_b);

    -- twoToMiSiYip_uid151_atan2Test(BITSELECT,150)@3
    twoToMiSiYip_uid151_atan2Test_b <= STD_LOGIC_VECTOR(yip1_7_uid144_atan2Test_b(24 downto 7));

    -- xip1E_8_uid154_atan2Test(ADDSUB,153)@3
    xip1E_8_uid154_atan2Test_s <= invSignOfSelectionSignal_uid153_atan2Test_q;
    xip1E_8_uid154_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & xip1_7_uid143_atan2Test_b));
    xip1E_8_uid154_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((32 downto 18 => twoToMiSiYip_uid151_atan2Test_b(17)) & twoToMiSiYip_uid151_atan2Test_b));
    xip1E_8_uid154_atan2Test_combproc: PROCESS (xip1E_8_uid154_atan2Test_a, xip1E_8_uid154_atan2Test_b, xip1E_8_uid154_atan2Test_s)
    BEGIN
        IF (xip1E_8_uid154_atan2Test_s = "1") THEN
            xip1E_8_uid154_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_8_uid154_atan2Test_a) + SIGNED(xip1E_8_uid154_atan2Test_b));
        ELSE
            xip1E_8_uid154_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_8_uid154_atan2Test_a) - SIGNED(xip1E_8_uid154_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_8_uid154_atan2Test_q <= xip1E_8_uid154_atan2Test_o(31 downto 0);

    -- xip1_8_uid160_atan2Test(BITSELECT,159)@3
    xip1_8_uid160_atan2Test_in <= xip1E_8_uid154_atan2Test_q(29 downto 0);
    xip1_8_uid160_atan2Test_b <= xip1_8_uid160_atan2Test_in(29 downto 0);

    -- redist5_xip1_8_uid160_atan2Test_b_1(DELAY,247)
    redist5_xip1_8_uid160_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 30, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => xip1_8_uid160_atan2Test_b, xout => redist5_xip1_8_uid160_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- xip1E_9_uid171_atan2Test(ADDSUB,170)@4
    xip1E_9_uid171_atan2Test_s <= invSignOfSelectionSignal_uid170_atan2Test_q;
    xip1E_9_uid171_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("000" & redist5_xip1_8_uid160_atan2Test_b_1_q));
    xip1E_9_uid171_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((32 downto 16 => twoToMiSiYip_uid168_atan2Test_b(15)) & twoToMiSiYip_uid168_atan2Test_b));
    xip1E_9_uid171_atan2Test_combproc: PROCESS (xip1E_9_uid171_atan2Test_a, xip1E_9_uid171_atan2Test_b, xip1E_9_uid171_atan2Test_s)
    BEGIN
        IF (xip1E_9_uid171_atan2Test_s = "1") THEN
            xip1E_9_uid171_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_9_uid171_atan2Test_a) + SIGNED(xip1E_9_uid171_atan2Test_b));
        ELSE
            xip1E_9_uid171_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(xip1E_9_uid171_atan2Test_a) - SIGNED(xip1E_9_uid171_atan2Test_b));
        END IF;
    END PROCESS;
    xip1E_9_uid171_atan2Test_q <= xip1E_9_uid171_atan2Test_o(31 downto 0);

    -- xip1_9_uid177_atan2Test(BITSELECT,176)@4
    xip1_9_uid177_atan2Test_in <= xip1E_9_uid171_atan2Test_q(29 downto 0);
    xip1_9_uid177_atan2Test_b <= xip1_9_uid177_atan2Test_in(29 downto 0);

    -- twoToMiSiXip_uid184_atan2Test(BITSELECT,183)@4
    twoToMiSiXip_uid184_atan2Test_b <= xip1_9_uid177_atan2Test_b(29 downto 9);

    -- twoToMiSiXip_uid167_atan2Test(BITSELECT,166)@4
    twoToMiSiXip_uid167_atan2Test_b <= redist5_xip1_8_uid160_atan2Test_b_1_q(29 downto 8);

    -- yip1E_9_uid172_atan2Test(ADDSUB,171)@4
    yip1E_9_uid172_atan2Test_s <= xMSB_uid163_atan2Test_b;
    yip1E_9_uid172_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((25 downto 24 => redist4_yip1_8_uid161_atan2Test_b_1_q(23)) & redist4_yip1_8_uid161_atan2Test_b_1_q));
    yip1E_9_uid172_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("0000" & twoToMiSiXip_uid167_atan2Test_b));
    yip1E_9_uid172_atan2Test_combproc: PROCESS (yip1E_9_uid172_atan2Test_a, yip1E_9_uid172_atan2Test_b, yip1E_9_uid172_atan2Test_s)
    BEGIN
        IF (yip1E_9_uid172_atan2Test_s = "1") THEN
            yip1E_9_uid172_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_9_uid172_atan2Test_a) + SIGNED(yip1E_9_uid172_atan2Test_b));
        ELSE
            yip1E_9_uid172_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_9_uid172_atan2Test_a) - SIGNED(yip1E_9_uid172_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_9_uid172_atan2Test_q <= yip1E_9_uid172_atan2Test_o(24 downto 0);

    -- yip1_9_uid178_atan2Test(BITSELECT,177)@4
    yip1_9_uid178_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_9_uid172_atan2Test_q(22 downto 0));
    yip1_9_uid178_atan2Test_b <= STD_LOGIC_VECTOR(yip1_9_uid178_atan2Test_in(22 downto 0));

    -- yip1E_10_uid189_atan2Test(ADDSUB,188)@4
    yip1E_10_uid189_atan2Test_s <= xMSB_uid180_atan2Test_b;
    yip1E_10_uid189_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((24 downto 23 => yip1_9_uid178_atan2Test_b(22)) & yip1_9_uid178_atan2Test_b));
    yip1E_10_uid189_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR("0000" & twoToMiSiXip_uid184_atan2Test_b));
    yip1E_10_uid189_atan2Test_combproc: PROCESS (yip1E_10_uid189_atan2Test_a, yip1E_10_uid189_atan2Test_b, yip1E_10_uid189_atan2Test_s)
    BEGIN
        IF (yip1E_10_uid189_atan2Test_s = "1") THEN
            yip1E_10_uid189_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_10_uid189_atan2Test_a) + SIGNED(yip1E_10_uid189_atan2Test_b));
        ELSE
            yip1E_10_uid189_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(yip1E_10_uid189_atan2Test_a) - SIGNED(yip1E_10_uid189_atan2Test_b));
        END IF;
    END PROCESS;
    yip1E_10_uid189_atan2Test_q <= yip1E_10_uid189_atan2Test_o(23 downto 0);

    -- yip1_10_uid195_atan2Test(BITSELECT,194)@4
    yip1_10_uid195_atan2Test_in <= STD_LOGIC_VECTOR(yip1E_10_uid189_atan2Test_q(21 downto 0));
    yip1_10_uid195_atan2Test_b <= STD_LOGIC_VECTOR(yip1_10_uid195_atan2Test_in(21 downto 0));

    -- xMSB_uid197_atan2Test(BITSELECT,196)@4
    xMSB_uid197_atan2Test_b <= STD_LOGIC_VECTOR(yip1_10_uid195_atan2Test_b(21 downto 21));

    -- redist2_xMSB_uid197_atan2Test_b_1(DELAY,244)
    redist2_xMSB_uid197_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 1, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => xMSB_uid197_atan2Test_b, xout => redist2_xMSB_uid197_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- invSignOfSelectionSignal_uid207_atan2Test(LOGICAL,206)@5
    invSignOfSelectionSignal_uid207_atan2Test_q <= not (redist2_xMSB_uid197_atan2Test_b_1_q);

    -- cstArcTan2Mi_10_uid203_atan2Test(CONSTANT,202)
    cstArcTan2Mi_10_uid203_atan2Test_q <= "011111111111111111111101010101";

    -- invSignOfSelectionSignal_uid190_atan2Test(LOGICAL,189)@4 + 1
    invSignOfSelectionSignal_uid190_atan2Test_qi <= not (xMSB_uid180_atan2Test_b);
    invSignOfSelectionSignal_uid190_atan2Test_delay : dspba_delay
    GENERIC MAP ( width => 1, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => invSignOfSelectionSignal_uid190_atan2Test_qi, xout => invSignOfSelectionSignal_uid190_atan2Test_q, clk => clk, aclr => areset );

    -- cstArcTan2Mi_9_uid186_atan2Test(CONSTANT,185)
    cstArcTan2Mi_9_uid186_atan2Test_q <= "01111111111111111111010101011";

    -- cstArcTan2Mi_8_uid169_atan2Test(CONSTANT,168)
    cstArcTan2Mi_8_uid169_atan2Test_q <= "0111111111111111110101010101";

    -- redist6_invSignOfSelectionSignal_uid153_atan2Test_q_1(DELAY,248)
    redist6_invSignOfSelectionSignal_uid153_atan2Test_q_1 : dspba_delay
    GENERIC MAP ( width => 1, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => invSignOfSelectionSignal_uid153_atan2Test_q, xout => redist6_invSignOfSelectionSignal_uid153_atan2Test_q_1_q, clk => clk, aclr => areset );

    -- cstArcTan2Mi_7_uid152_atan2Test(CONSTANT,151)
    cstArcTan2Mi_7_uid152_atan2Test_q <= "011111111111111101010101011";

    -- cstArcTan2Mi_6_uid135_atan2Test(CONSTANT,134)
    cstArcTan2Mi_6_uid135_atan2Test_q <= "01111111111111010101010110";

    -- redist10_invSignOfSelectionSignal_uid115_atan2Test_q_1(DELAY,252)
    redist10_invSignOfSelectionSignal_uid115_atan2Test_q_1 : dspba_delay
    GENERIC MAP ( width => 1, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => invSignOfSelectionSignal_uid115_atan2Test_q, xout => redist10_invSignOfSelectionSignal_uid115_atan2Test_q_1_q, clk => clk, aclr => areset );

    -- cstArcTan2Mi_5_uid114_atan2Test(CONSTANT,113)
    cstArcTan2Mi_5_uid114_atan2Test_q <= "0111111111110101010101110";

    -- cstArcTan2Mi_4_uid93_atan2Test(CONSTANT,92)
    cstArcTan2Mi_4_uid93_atan2Test_q <= "011111111101010101101111";

    -- redist14_invSignOfSelectionSignal_uid75_atan2Test_q_1(DELAY,256)
    redist14_invSignOfSelectionSignal_uid75_atan2Test_q_1 : dspba_delay
    GENERIC MAP ( width => 1, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => invSignOfSelectionSignal_uid75_atan2Test_q, xout => redist14_invSignOfSelectionSignal_uid75_atan2Test_q_1_q, clk => clk, aclr => areset );

    -- cstArcTan2Mi_3_uid74_atan2Test(CONSTANT,73)
    cstArcTan2Mi_3_uid74_atan2Test_q <= "01111111010101101110101";

    -- cstArcTan2Mi_2_uid55_atan2Test(CONSTANT,54)
    cstArcTan2Mi_2_uid55_atan2Test_q <= "0111110101101101110110";

    -- cstArcTan2Mi_1_uid36_atan2Test(CONSTANT,35)
    cstArcTan2Mi_1_uid36_atan2Test_q <= "011101101011000110100";

    -- cstArcTan2Mi_0_uid22_atan2Test(CONSTANT,21)
    cstArcTan2Mi_0_uid22_atan2Test_q <= "01100100100001111111";

    -- highBBits_uid26_atan2Test(BITSELECT,25)@1
    highBBits_uid26_atan2Test_b <= STD_LOGIC_VECTOR(cstArcTan2Mi_0_uid22_atan2Test_q(19 downto 19));

    -- lowRangeB_uid25_atan2Test(BITSELECT,24)@1
    lowRangeB_uid25_atan2Test_in <= cstArcTan2Mi_0_uid22_atan2Test_q(18 downto 0);
    lowRangeB_uid25_atan2Test_b <= lowRangeB_uid25_atan2Test_in(18 downto 0);

    -- aip1E_1_uid28_atan2Test(BITJOIN,27)@1
    aip1E_1_uid28_atan2Test_q <= STD_LOGIC_VECTOR((2 downto 1 => highBBits_uid26_atan2Test_b(0)) & highBBits_uid26_atan2Test_b) & lowRangeB_uid25_atan2Test_b;

    -- aip1E_uid31_atan2Test(BITSELECT,30)@1
    aip1E_uid31_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_1_uid28_atan2Test_q(20 downto 0));
    aip1E_uid31_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid31_atan2Test_in(20 downto 0));

    -- aip1E_2NA_uid46_atan2Test(BITJOIN,45)@1
    aip1E_2NA_uid46_atan2Test_q <= aip1E_uid31_atan2Test_b & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_2sumAHighB_uid47_atan2Test(ADDSUB,46)@1
    aip1E_2sumAHighB_uid47_atan2Test_s <= invSignOfSelectionSignal_uid37_atan2Test_q;
    aip1E_2sumAHighB_uid47_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((24 downto 23 => aip1E_2NA_uid46_atan2Test_q(22)) & aip1E_2NA_uid46_atan2Test_q));
    aip1E_2sumAHighB_uid47_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((24 downto 21 => cstArcTan2Mi_1_uid36_atan2Test_q(20)) & cstArcTan2Mi_1_uid36_atan2Test_q));
    aip1E_2sumAHighB_uid47_atan2Test_combproc: PROCESS (aip1E_2sumAHighB_uid47_atan2Test_a, aip1E_2sumAHighB_uid47_atan2Test_b, aip1E_2sumAHighB_uid47_atan2Test_s)
    BEGIN
        IF (aip1E_2sumAHighB_uid47_atan2Test_s = "1") THEN
            aip1E_2sumAHighB_uid47_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_2sumAHighB_uid47_atan2Test_a) + SIGNED(aip1E_2sumAHighB_uid47_atan2Test_b));
        ELSE
            aip1E_2sumAHighB_uid47_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_2sumAHighB_uid47_atan2Test_a) - SIGNED(aip1E_2sumAHighB_uid47_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_2sumAHighB_uid47_atan2Test_q <= aip1E_2sumAHighB_uid47_atan2Test_o(23 downto 0);

    -- aip1E_uid50_atan2Test(BITSELECT,49)@1
    aip1E_uid50_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_2sumAHighB_uid47_atan2Test_q(22 downto 0));
    aip1E_uid50_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid50_atan2Test_in(22 downto 0));

    -- aip1E_3NA_uid65_atan2Test(BITJOIN,64)@1
    aip1E_3NA_uid65_atan2Test_q <= aip1E_uid50_atan2Test_b & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_3sumAHighB_uid66_atan2Test(ADDSUB,65)@1
    aip1E_3sumAHighB_uid66_atan2Test_s <= invSignOfSelectionSignal_uid56_atan2Test_q;
    aip1E_3sumAHighB_uid66_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((26 downto 25 => aip1E_3NA_uid65_atan2Test_q(24)) & aip1E_3NA_uid65_atan2Test_q));
    aip1E_3sumAHighB_uid66_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((26 downto 22 => cstArcTan2Mi_2_uid55_atan2Test_q(21)) & cstArcTan2Mi_2_uid55_atan2Test_q));
    aip1E_3sumAHighB_uid66_atan2Test_combproc: PROCESS (aip1E_3sumAHighB_uid66_atan2Test_a, aip1E_3sumAHighB_uid66_atan2Test_b, aip1E_3sumAHighB_uid66_atan2Test_s)
    BEGIN
        IF (aip1E_3sumAHighB_uid66_atan2Test_s = "1") THEN
            aip1E_3sumAHighB_uid66_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_3sumAHighB_uid66_atan2Test_a) + SIGNED(aip1E_3sumAHighB_uid66_atan2Test_b));
        ELSE
            aip1E_3sumAHighB_uid66_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_3sumAHighB_uid66_atan2Test_a) - SIGNED(aip1E_3sumAHighB_uid66_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_3sumAHighB_uid66_atan2Test_q <= aip1E_3sumAHighB_uid66_atan2Test_o(25 downto 0);

    -- aip1E_uid69_atan2Test(BITSELECT,68)@1
    aip1E_uid69_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_3sumAHighB_uid66_atan2Test_q(24 downto 0));
    aip1E_uid69_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid69_atan2Test_in(24 downto 0));

    -- redist15_aip1E_uid69_atan2Test_b_1(DELAY,257)
    redist15_aip1E_uid69_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 25, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => aip1E_uid69_atan2Test_b, xout => redist15_aip1E_uid69_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- aip1E_4NA_uid84_atan2Test(BITJOIN,83)@2
    aip1E_4NA_uid84_atan2Test_q <= redist15_aip1E_uid69_atan2Test_b_1_q & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_4sumAHighB_uid85_atan2Test(ADDSUB,84)@2
    aip1E_4sumAHighB_uid85_atan2Test_s <= redist14_invSignOfSelectionSignal_uid75_atan2Test_q_1_q;
    aip1E_4sumAHighB_uid85_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((28 downto 27 => aip1E_4NA_uid84_atan2Test_q(26)) & aip1E_4NA_uid84_atan2Test_q));
    aip1E_4sumAHighB_uid85_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((28 downto 23 => cstArcTan2Mi_3_uid74_atan2Test_q(22)) & cstArcTan2Mi_3_uid74_atan2Test_q));
    aip1E_4sumAHighB_uid85_atan2Test_combproc: PROCESS (aip1E_4sumAHighB_uid85_atan2Test_a, aip1E_4sumAHighB_uid85_atan2Test_b, aip1E_4sumAHighB_uid85_atan2Test_s)
    BEGIN
        IF (aip1E_4sumAHighB_uid85_atan2Test_s = "1") THEN
            aip1E_4sumAHighB_uid85_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_4sumAHighB_uid85_atan2Test_a) + SIGNED(aip1E_4sumAHighB_uid85_atan2Test_b));
        ELSE
            aip1E_4sumAHighB_uid85_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_4sumAHighB_uid85_atan2Test_a) - SIGNED(aip1E_4sumAHighB_uid85_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_4sumAHighB_uid85_atan2Test_q <= aip1E_4sumAHighB_uid85_atan2Test_o(27 downto 0);

    -- aip1E_uid88_atan2Test(BITSELECT,87)@2
    aip1E_uid88_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_4sumAHighB_uid85_atan2Test_q(26 downto 0));
    aip1E_uid88_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid88_atan2Test_in(26 downto 0));

    -- aip1E_5NA_uid103_atan2Test(BITJOIN,102)@2
    aip1E_5NA_uid103_atan2Test_q <= aip1E_uid88_atan2Test_b & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_5sumAHighB_uid104_atan2Test(ADDSUB,103)@2
    aip1E_5sumAHighB_uid104_atan2Test_s <= invSignOfSelectionSignal_uid94_atan2Test_q;
    aip1E_5sumAHighB_uid104_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((30 downto 29 => aip1E_5NA_uid103_atan2Test_q(28)) & aip1E_5NA_uid103_atan2Test_q));
    aip1E_5sumAHighB_uid104_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((30 downto 24 => cstArcTan2Mi_4_uid93_atan2Test_q(23)) & cstArcTan2Mi_4_uid93_atan2Test_q));
    aip1E_5sumAHighB_uid104_atan2Test_combproc: PROCESS (aip1E_5sumAHighB_uid104_atan2Test_a, aip1E_5sumAHighB_uid104_atan2Test_b, aip1E_5sumAHighB_uid104_atan2Test_s)
    BEGIN
        IF (aip1E_5sumAHighB_uid104_atan2Test_s = "1") THEN
            aip1E_5sumAHighB_uid104_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_5sumAHighB_uid104_atan2Test_a) + SIGNED(aip1E_5sumAHighB_uid104_atan2Test_b));
        ELSE
            aip1E_5sumAHighB_uid104_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_5sumAHighB_uid104_atan2Test_a) - SIGNED(aip1E_5sumAHighB_uid104_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_5sumAHighB_uid104_atan2Test_q <= aip1E_5sumAHighB_uid104_atan2Test_o(29 downto 0);

    -- aip1E_uid107_atan2Test(BITSELECT,106)@2
    aip1E_uid107_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_5sumAHighB_uid104_atan2Test_q(28 downto 0));
    aip1E_uid107_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid107_atan2Test_in(28 downto 0));

    -- redist11_aip1E_uid107_atan2Test_b_1(DELAY,253)
    redist11_aip1E_uid107_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 29, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => aip1E_uid107_atan2Test_b, xout => redist11_aip1E_uid107_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- aip1E_6NA_uid124_atan2Test(BITJOIN,123)@3
    aip1E_6NA_uid124_atan2Test_q <= redist11_aip1E_uid107_atan2Test_b_1_q & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_6sumAHighB_uid125_atan2Test(ADDSUB,124)@3
    aip1E_6sumAHighB_uid125_atan2Test_s <= redist10_invSignOfSelectionSignal_uid115_atan2Test_q_1_q;
    aip1E_6sumAHighB_uid125_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((32 downto 31 => aip1E_6NA_uid124_atan2Test_q(30)) & aip1E_6NA_uid124_atan2Test_q));
    aip1E_6sumAHighB_uid125_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((32 downto 25 => cstArcTan2Mi_5_uid114_atan2Test_q(24)) & cstArcTan2Mi_5_uid114_atan2Test_q));
    aip1E_6sumAHighB_uid125_atan2Test_combproc: PROCESS (aip1E_6sumAHighB_uid125_atan2Test_a, aip1E_6sumAHighB_uid125_atan2Test_b, aip1E_6sumAHighB_uid125_atan2Test_s)
    BEGIN
        IF (aip1E_6sumAHighB_uid125_atan2Test_s = "1") THEN
            aip1E_6sumAHighB_uid125_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_6sumAHighB_uid125_atan2Test_a) + SIGNED(aip1E_6sumAHighB_uid125_atan2Test_b));
        ELSE
            aip1E_6sumAHighB_uid125_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_6sumAHighB_uid125_atan2Test_a) - SIGNED(aip1E_6sumAHighB_uid125_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_6sumAHighB_uid125_atan2Test_q <= aip1E_6sumAHighB_uid125_atan2Test_o(31 downto 0);

    -- aip1E_uid128_atan2Test(BITSELECT,127)@3
    aip1E_uid128_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_6sumAHighB_uid125_atan2Test_q(30 downto 0));
    aip1E_uid128_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid128_atan2Test_in(30 downto 0));

    -- aip1E_7NA_uid141_atan2Test(BITJOIN,140)@3
    aip1E_7NA_uid141_atan2Test_q <= aip1E_uid128_atan2Test_b & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_7sumAHighB_uid142_atan2Test(ADDSUB,141)@3
    aip1E_7sumAHighB_uid142_atan2Test_s <= invSignOfSelectionSignal_uid136_atan2Test_q;
    aip1E_7sumAHighB_uid142_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((34 downto 33 => aip1E_7NA_uid141_atan2Test_q(32)) & aip1E_7NA_uid141_atan2Test_q));
    aip1E_7sumAHighB_uid142_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((34 downto 26 => cstArcTan2Mi_6_uid135_atan2Test_q(25)) & cstArcTan2Mi_6_uid135_atan2Test_q));
    aip1E_7sumAHighB_uid142_atan2Test_combproc: PROCESS (aip1E_7sumAHighB_uid142_atan2Test_a, aip1E_7sumAHighB_uid142_atan2Test_b, aip1E_7sumAHighB_uid142_atan2Test_s)
    BEGIN
        IF (aip1E_7sumAHighB_uid142_atan2Test_s = "1") THEN
            aip1E_7sumAHighB_uid142_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_7sumAHighB_uid142_atan2Test_a) + SIGNED(aip1E_7sumAHighB_uid142_atan2Test_b));
        ELSE
            aip1E_7sumAHighB_uid142_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_7sumAHighB_uid142_atan2Test_a) - SIGNED(aip1E_7sumAHighB_uid142_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_7sumAHighB_uid142_atan2Test_q <= aip1E_7sumAHighB_uid142_atan2Test_o(33 downto 0);

    -- aip1E_uid145_atan2Test(BITSELECT,144)@3
    aip1E_uid145_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_7sumAHighB_uid142_atan2Test_q(32 downto 0));
    aip1E_uid145_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid145_atan2Test_in(32 downto 0));

    -- redist7_aip1E_uid145_atan2Test_b_1(DELAY,249)
    redist7_aip1E_uid145_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 33, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => aip1E_uid145_atan2Test_b, xout => redist7_aip1E_uid145_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- aip1E_8NA_uid158_atan2Test(BITJOIN,157)@4
    aip1E_8NA_uid158_atan2Test_q <= redist7_aip1E_uid145_atan2Test_b_1_q & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_8sumAHighB_uid159_atan2Test(ADDSUB,158)@4
    aip1E_8sumAHighB_uid159_atan2Test_s <= redist6_invSignOfSelectionSignal_uid153_atan2Test_q_1_q;
    aip1E_8sumAHighB_uid159_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((36 downto 35 => aip1E_8NA_uid158_atan2Test_q(34)) & aip1E_8NA_uid158_atan2Test_q));
    aip1E_8sumAHighB_uid159_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((36 downto 27 => cstArcTan2Mi_7_uid152_atan2Test_q(26)) & cstArcTan2Mi_7_uid152_atan2Test_q));
    aip1E_8sumAHighB_uid159_atan2Test_combproc: PROCESS (aip1E_8sumAHighB_uid159_atan2Test_a, aip1E_8sumAHighB_uid159_atan2Test_b, aip1E_8sumAHighB_uid159_atan2Test_s)
    BEGIN
        IF (aip1E_8sumAHighB_uid159_atan2Test_s = "1") THEN
            aip1E_8sumAHighB_uid159_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_8sumAHighB_uid159_atan2Test_a) + SIGNED(aip1E_8sumAHighB_uid159_atan2Test_b));
        ELSE
            aip1E_8sumAHighB_uid159_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_8sumAHighB_uid159_atan2Test_a) - SIGNED(aip1E_8sumAHighB_uid159_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_8sumAHighB_uid159_atan2Test_q <= aip1E_8sumAHighB_uid159_atan2Test_o(35 downto 0);

    -- aip1E_uid162_atan2Test(BITSELECT,161)@4
    aip1E_uid162_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_8sumAHighB_uid159_atan2Test_q(34 downto 0));
    aip1E_uid162_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid162_atan2Test_in(34 downto 0));

    -- aip1E_9NA_uid175_atan2Test(BITJOIN,174)@4
    aip1E_9NA_uid175_atan2Test_q <= aip1E_uid162_atan2Test_b & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_9sumAHighB_uid176_atan2Test(ADDSUB,175)@4
    aip1E_9sumAHighB_uid176_atan2Test_s <= invSignOfSelectionSignal_uid170_atan2Test_q;
    aip1E_9sumAHighB_uid176_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((38 downto 37 => aip1E_9NA_uid175_atan2Test_q(36)) & aip1E_9NA_uid175_atan2Test_q));
    aip1E_9sumAHighB_uid176_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((38 downto 28 => cstArcTan2Mi_8_uid169_atan2Test_q(27)) & cstArcTan2Mi_8_uid169_atan2Test_q));
    aip1E_9sumAHighB_uid176_atan2Test_combproc: PROCESS (aip1E_9sumAHighB_uid176_atan2Test_a, aip1E_9sumAHighB_uid176_atan2Test_b, aip1E_9sumAHighB_uid176_atan2Test_s)
    BEGIN
        IF (aip1E_9sumAHighB_uid176_atan2Test_s = "1") THEN
            aip1E_9sumAHighB_uid176_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_9sumAHighB_uid176_atan2Test_a) + SIGNED(aip1E_9sumAHighB_uid176_atan2Test_b));
        ELSE
            aip1E_9sumAHighB_uid176_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_9sumAHighB_uid176_atan2Test_a) - SIGNED(aip1E_9sumAHighB_uid176_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_9sumAHighB_uid176_atan2Test_q <= aip1E_9sumAHighB_uid176_atan2Test_o(37 downto 0);

    -- aip1E_uid179_atan2Test(BITSELECT,178)@4
    aip1E_uid179_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_9sumAHighB_uid176_atan2Test_q(36 downto 0));
    aip1E_uid179_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid179_atan2Test_in(36 downto 0));

    -- redist3_aip1E_uid179_atan2Test_b_1(DELAY,245)
    redist3_aip1E_uid179_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 37, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => aip1E_uid179_atan2Test_b, xout => redist3_aip1E_uid179_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- aip1E_10NA_uid192_atan2Test(BITJOIN,191)@5
    aip1E_10NA_uid192_atan2Test_q <= redist3_aip1E_uid179_atan2Test_b_1_q & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_10sumAHighB_uid193_atan2Test(ADDSUB,192)@5
    aip1E_10sumAHighB_uid193_atan2Test_s <= invSignOfSelectionSignal_uid190_atan2Test_q;
    aip1E_10sumAHighB_uid193_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((40 downto 39 => aip1E_10NA_uid192_atan2Test_q(38)) & aip1E_10NA_uid192_atan2Test_q));
    aip1E_10sumAHighB_uid193_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((40 downto 29 => cstArcTan2Mi_9_uid186_atan2Test_q(28)) & cstArcTan2Mi_9_uid186_atan2Test_q));
    aip1E_10sumAHighB_uid193_atan2Test_combproc: PROCESS (aip1E_10sumAHighB_uid193_atan2Test_a, aip1E_10sumAHighB_uid193_atan2Test_b, aip1E_10sumAHighB_uid193_atan2Test_s)
    BEGIN
        IF (aip1E_10sumAHighB_uid193_atan2Test_s = "1") THEN
            aip1E_10sumAHighB_uid193_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_10sumAHighB_uid193_atan2Test_a) + SIGNED(aip1E_10sumAHighB_uid193_atan2Test_b));
        ELSE
            aip1E_10sumAHighB_uid193_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_10sumAHighB_uid193_atan2Test_a) - SIGNED(aip1E_10sumAHighB_uid193_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_10sumAHighB_uid193_atan2Test_q <= aip1E_10sumAHighB_uid193_atan2Test_o(39 downto 0);

    -- aip1E_uid196_atan2Test(BITSELECT,195)@5
    aip1E_uid196_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_10sumAHighB_uid193_atan2Test_q(38 downto 0));
    aip1E_uid196_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid196_atan2Test_in(38 downto 0));

    -- aip1E_11NA_uid209_atan2Test(BITJOIN,208)@5
    aip1E_11NA_uid209_atan2Test_q <= aip1E_uid196_atan2Test_b & aip1E_2CostZeroPaddingA_uid45_atan2Test_q;

    -- aip1E_11sumAHighB_uid210_atan2Test(ADDSUB,209)@5
    aip1E_11sumAHighB_uid210_atan2Test_s <= invSignOfSelectionSignal_uid207_atan2Test_q;
    aip1E_11sumAHighB_uid210_atan2Test_a <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((42 downto 41 => aip1E_11NA_uid209_atan2Test_q(40)) & aip1E_11NA_uid209_atan2Test_q));
    aip1E_11sumAHighB_uid210_atan2Test_b <= STD_LOGIC_VECTOR(STD_LOGIC_VECTOR((42 downto 30 => cstArcTan2Mi_10_uid203_atan2Test_q(29)) & cstArcTan2Mi_10_uid203_atan2Test_q));
    aip1E_11sumAHighB_uid210_atan2Test_combproc: PROCESS (aip1E_11sumAHighB_uid210_atan2Test_a, aip1E_11sumAHighB_uid210_atan2Test_b, aip1E_11sumAHighB_uid210_atan2Test_s)
    BEGIN
        IF (aip1E_11sumAHighB_uid210_atan2Test_s = "1") THEN
            aip1E_11sumAHighB_uid210_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_11sumAHighB_uid210_atan2Test_a) + SIGNED(aip1E_11sumAHighB_uid210_atan2Test_b));
        ELSE
            aip1E_11sumAHighB_uid210_atan2Test_o <= STD_LOGIC_VECTOR(SIGNED(aip1E_11sumAHighB_uid210_atan2Test_a) - SIGNED(aip1E_11sumAHighB_uid210_atan2Test_b));
        END IF;
    END PROCESS;
    aip1E_11sumAHighB_uid210_atan2Test_q <= aip1E_11sumAHighB_uid210_atan2Test_o(41 downto 0);

    -- aip1E_uid213_atan2Test(BITSELECT,212)@5
    aip1E_uid213_atan2Test_in <= STD_LOGIC_VECTOR(aip1E_11sumAHighB_uid210_atan2Test_q(40 downto 0));
    aip1E_uid213_atan2Test_b <= STD_LOGIC_VECTOR(aip1E_uid213_atan2Test_in(40 downto 0));

    -- alphaPreRnd_uid214_atan2Test(BITSELECT,213)@5
    alphaPreRnd_uid214_atan2Test_b <= aip1E_uid213_atan2Test_b(40 downto 29);

    -- redist1_alphaPreRnd_uid214_atan2Test_b_1(DELAY,243)
    redist1_alphaPreRnd_uid214_atan2Test_b_1 : dspba_delay
    GENERIC MAP ( width => 12, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => alphaPreRnd_uid214_atan2Test_b, xout => redist1_alphaPreRnd_uid214_atan2Test_b_1_q, clk => clk, aclr => areset );

    -- lowRangeA_uid218_atan2Test_merged_bit_select(BITSELECT,241)@6
    lowRangeA_uid218_atan2Test_merged_bit_select_b <= redist1_alphaPreRnd_uid214_atan2Test_b_1_q(0 downto 0);
    lowRangeA_uid218_atan2Test_merged_bit_select_c <= redist1_alphaPreRnd_uid214_atan2Test_b_1_q(11 downto 1);

    -- alphaPostRnd_uid221_atan2Test(BITJOIN,220)@6
    alphaPostRnd_uid221_atan2Test_q <= alphaPostRndhigh_uid220_atan2Test_q & lowRangeA_uid218_atan2Test_merged_bit_select_b;

    -- atanRes_uid222_atan2Test(BITSELECT,221)@6
    atanRes_uid222_atan2Test_in <= alphaPostRnd_uid221_atan2Test_q(11 downto 0);
    atanRes_uid222_atan2Test_b <= atanRes_uid222_atan2Test_in(11 downto 0);

    -- xNotZero_uid17_atan2Test(LOGICAL,16)@0 + 1
    xNotZero_uid17_atan2Test_qi <= "1" WHEN x /= "000000000000000000" ELSE "0";
    xNotZero_uid17_atan2Test_delay : dspba_delay
    GENERIC MAP ( width => 1, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => xNotZero_uid17_atan2Test_qi, xout => xNotZero_uid17_atan2Test_q, clk => clk, aclr => areset );

    -- redist16_xNotZero_uid17_atan2Test_q_6(DELAY,258)
    redist16_xNotZero_uid17_atan2Test_q_6 : dspba_delay
    GENERIC MAP ( width => 1, depth => 5, reset_kind => "ASYNC" )
    PORT MAP ( xin => xNotZero_uid17_atan2Test_q, xout => redist16_xNotZero_uid17_atan2Test_q_6_q, clk => clk, aclr => areset );

    -- xZero_uid18_atan2Test(LOGICAL,17)@6
    xZero_uid18_atan2Test_q <= not (redist16_xNotZero_uid17_atan2Test_q_6_q);

    -- yNotZero_uid15_atan2Test(LOGICAL,14)@0 + 1
    yNotZero_uid15_atan2Test_qi <= "1" WHEN y /= "000000000000000000" ELSE "0";
    yNotZero_uid15_atan2Test_delay : dspba_delay
    GENERIC MAP ( width => 1, depth => 1, reset_kind => "ASYNC" )
    PORT MAP ( xin => yNotZero_uid15_atan2Test_qi, xout => yNotZero_uid15_atan2Test_q, clk => clk, aclr => areset );

    -- redist17_yNotZero_uid15_atan2Test_q_6(DELAY,259)
    redist17_yNotZero_uid15_atan2Test_q_6 : dspba_delay
    GENERIC MAP ( width => 1, depth => 5, reset_kind => "ASYNC" )
    PORT MAP ( xin => yNotZero_uid15_atan2Test_q, xout => redist17_yNotZero_uid15_atan2Test_q_6_q, clk => clk, aclr => areset );

    -- yZero_uid16_atan2Test(LOGICAL,15)@6
    yZero_uid16_atan2Test_q <= not (redist17_yNotZero_uid15_atan2Test_q_6_q);

    -- concXZeroYZero_uid229_atan2Test(BITJOIN,228)@6
    concXZeroYZero_uid229_atan2Test_q <= xZero_uid18_atan2Test_q & yZero_uid16_atan2Test_q;

    -- atanResPostExc_uid230_atan2Test(MUX,229)@6
    atanResPostExc_uid230_atan2Test_s <= concXZeroYZero_uid229_atan2Test_q;
    atanResPostExc_uid230_atan2Test_combproc: PROCESS (atanResPostExc_uid230_atan2Test_s, atanRes_uid222_atan2Test_b, cstZeroOutFormat_uid223_atan2Test_q, constPio2P2u_mergedSignalTM_uid227_atan2Test_q)
    BEGIN
        CASE (atanResPostExc_uid230_atan2Test_s) IS
            WHEN "00" => atanResPostExc_uid230_atan2Test_q <= atanRes_uid222_atan2Test_b;
            WHEN "01" => atanResPostExc_uid230_atan2Test_q <= cstZeroOutFormat_uid223_atan2Test_q;
            WHEN "10" => atanResPostExc_uid230_atan2Test_q <= constPio2P2u_mergedSignalTM_uid227_atan2Test_q;
            WHEN "11" => atanResPostExc_uid230_atan2Test_q <= cstZeroOutFormat_uid223_atan2Test_q;
            WHEN OTHERS => atanResPostExc_uid230_atan2Test_q <= (others => '0');
        END CASE;
    END PROCESS;

    -- constantZeroOutFormat_uid234_atan2Test(CONSTANT,233)
    constantZeroOutFormat_uid234_atan2Test_q <= "000000000000";

    -- redist19_signX_uid7_atan2Test_b_6(DELAY,261)
    redist19_signX_uid7_atan2Test_b_6 : dspba_delay
    GENERIC MAP ( width => 1, depth => 6, reset_kind => "ASYNC" )
    PORT MAP ( xin => signX_uid7_atan2Test_b, xout => redist19_signX_uid7_atan2Test_b_6_q, clk => clk, aclr => areset );

    -- redist18_signY_uid8_atan2Test_b_6(DELAY,260)
    redist18_signY_uid8_atan2Test_b_6 : dspba_delay
    GENERIC MAP ( width => 1, depth => 6, reset_kind => "ASYNC" )
    PORT MAP ( xin => signY_uid8_atan2Test_b, xout => redist18_signY_uid8_atan2Test_b_6_q, clk => clk, aclr => areset );

    -- concSigns_uid231_atan2Test(BITJOIN,230)@6
    concSigns_uid231_atan2Test_q <= redist19_signX_uid7_atan2Test_b_6_q & redist18_signY_uid8_atan2Test_b_6_q;

    -- secondOperand_uid238_atan2Test(MUX,237)@6
    secondOperand_uid238_atan2Test_s <= concSigns_uid231_atan2Test_q;
    secondOperand_uid238_atan2Test_combproc: PROCESS (secondOperand_uid238_atan2Test_s, constantZeroOutFormat_uid234_atan2Test_q, atanResPostExc_uid230_atan2Test_q, constPi_uid233_atan2Test_q)
    BEGIN
        CASE (secondOperand_uid238_atan2Test_s) IS
            WHEN "00" => secondOperand_uid238_atan2Test_q <= constantZeroOutFormat_uid234_atan2Test_q;
            WHEN "01" => secondOperand_uid238_atan2Test_q <= atanResPostExc_uid230_atan2Test_q;
            WHEN "10" => secondOperand_uid238_atan2Test_q <= atanResPostExc_uid230_atan2Test_q;
            WHEN "11" => secondOperand_uid238_atan2Test_q <= constPi_uid233_atan2Test_q;
            WHEN OTHERS => secondOperand_uid238_atan2Test_q <= (others => '0');
        END CASE;
    END PROCESS;

    -- constPiP2u_uid232_atan2Test(CONSTANT,231)
    constPiP2u_uid232_atan2Test_q <= "110010010100";

    -- constantZeroOutFormatP2u_uid235_atan2Test(CONSTANT,234)
    constantZeroOutFormatP2u_uid235_atan2Test_q <= "000000000100";

    -- firstOperand_uid237_atan2Test(MUX,236)@6
    firstOperand_uid237_atan2Test_s <= concSigns_uid231_atan2Test_q;
    firstOperand_uid237_atan2Test_combproc: PROCESS (firstOperand_uid237_atan2Test_s, atanResPostExc_uid230_atan2Test_q, constantZeroOutFormatP2u_uid235_atan2Test_q, constPiP2u_uid232_atan2Test_q)
    BEGIN
        CASE (firstOperand_uid237_atan2Test_s) IS
            WHEN "00" => firstOperand_uid237_atan2Test_q <= atanResPostExc_uid230_atan2Test_q;
            WHEN "01" => firstOperand_uid237_atan2Test_q <= constantZeroOutFormatP2u_uid235_atan2Test_q;
            WHEN "10" => firstOperand_uid237_atan2Test_q <= constPiP2u_uid232_atan2Test_q;
            WHEN "11" => firstOperand_uid237_atan2Test_q <= atanResPostExc_uid230_atan2Test_q;
            WHEN OTHERS => firstOperand_uid237_atan2Test_q <= (others => '0');
        END CASE;
    END PROCESS;

    -- outResExtended_uid239_atan2Test(SUB,238)@6
    outResExtended_uid239_atan2Test_a <= STD_LOGIC_VECTOR("0" & firstOperand_uid237_atan2Test_q);
    outResExtended_uid239_atan2Test_b <= STD_LOGIC_VECTOR("0" & secondOperand_uid238_atan2Test_q);
    outResExtended_uid239_atan2Test_o <= STD_LOGIC_VECTOR(UNSIGNED(outResExtended_uid239_atan2Test_a) - UNSIGNED(outResExtended_uid239_atan2Test_b));
    outResExtended_uid239_atan2Test_q <= outResExtended_uid239_atan2Test_o(12 downto 0);

    -- atanResPostRR_uid240_atan2Test(BITSELECT,239)@6
    atanResPostRR_uid240_atan2Test_b <= STD_LOGIC_VECTOR(outResExtended_uid239_atan2Test_q(12 downto 2));

    -- VCC(CONSTANT,1)
    VCC_q <= "1";

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_wraddr(REG,264)
    redist0_atanResPostRR_uid240_atan2Test_b_94_wraddr_clkproc: PROCESS (clk, areset)
    BEGIN
        IF (areset = '1') THEN
            redist0_atanResPostRR_uid240_atan2Test_b_94_wraddr_q <= "1011100";
        ELSIF (clk'EVENT AND clk = '1') THEN
            redist0_atanResPostRR_uid240_atan2Test_b_94_wraddr_q <= STD_LOGIC_VECTOR(redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_q);
        END IF;
    END PROCESS;

    -- redist0_atanResPostRR_uid240_atan2Test_b_94_mem(DUALMEM,262)
    redist0_atanResPostRR_uid240_atan2Test_b_94_mem_ia <= STD_LOGIC_VECTOR(atanResPostRR_uid240_atan2Test_b);
    redist0_atanResPostRR_uid240_atan2Test_b_94_mem_aa <= redist0_atanResPostRR_uid240_atan2Test_b_94_wraddr_q;
    redist0_atanResPostRR_uid240_atan2Test_b_94_mem_ab <= redist0_atanResPostRR_uid240_atan2Test_b_94_rdcnt_q;
    redist0_atanResPostRR_uid240_atan2Test_b_94_mem_reset0 <= areset;
    redist0_atanResPostRR_uid240_atan2Test_b_94_mem_dmem : altsyncram
    GENERIC MAP (
        ram_block_type => "M9K",
        operation_mode => "DUAL_PORT",
        width_a => 11,
        widthad_a => 7,
        numwords_a => 93,
        width_b => 11,
        widthad_b => 7,
        numwords_b => 93,
        lpm_type => "altsyncram",
        width_byteena_a => 1,
        address_reg_b => "CLOCK0",
        indata_reg_b => "CLOCK0",
        wrcontrol_wraddress_reg_b => "CLOCK0",
        rdcontrol_reg_b => "CLOCK0",
        byteena_reg_b => "CLOCK0",
        outdata_reg_b => "CLOCK1",
        outdata_aclr_b => "CLEAR1",
        clock_enable_input_a => "NORMAL",
        clock_enable_input_b => "NORMAL",
        clock_enable_output_b => "NORMAL",
        read_during_write_mode_mixed_ports => "DONT_CARE",
        power_up_uninitialized => "TRUE",
        intended_device_family => "Cyclone IV E"
    )
    PORT MAP (
        clocken1 => redist0_atanResPostRR_uid240_atan2Test_b_94_enaAnd_q(0),
        clocken0 => VCC_q(0),
        clock0 => clk,
        aclr1 => redist0_atanResPostRR_uid240_atan2Test_b_94_mem_reset0,
        clock1 => clk,
        address_a => redist0_atanResPostRR_uid240_atan2Test_b_94_mem_aa,
        data_a => redist0_atanResPostRR_uid240_atan2Test_b_94_mem_ia,
        wren_a => VCC_q(0),
        address_b => redist0_atanResPostRR_uid240_atan2Test_b_94_mem_ab,
        q_b => redist0_atanResPostRR_uid240_atan2Test_b_94_mem_iq
    );
    redist0_atanResPostRR_uid240_atan2Test_b_94_mem_q <= redist0_atanResPostRR_uid240_atan2Test_b_94_mem_iq(10 downto 0);

    -- xOut(GPOUT,4)@100
    q <= redist0_atanResPostRR_uid240_atan2Test_b_94_mem_q;

END normal;
