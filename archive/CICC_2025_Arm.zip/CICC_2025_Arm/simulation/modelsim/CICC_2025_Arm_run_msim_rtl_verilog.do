transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+D:/Quartus_code/CICC_2025_Arm/rtl/SPI {D:/Quartus_code/CICC_2025_Arm/rtl/SPI/SPI_slave.v}
vlog -vlog01compat -work work +incdir+D:/Quartus_code/CICC_2025_Arm/rtl/SPI {D:/Quartus_code/CICC_2025_Arm/rtl/SPI/SPI_master.v}
vlog -vlog01compat -work work +incdir+D:/Quartus_code/CICC_2025_Arm/rtl/SPI/test {D:/Quartus_code/CICC_2025_Arm/rtl/SPI/test/test_SPI.v}
vlog -vlog01compat -work work +incdir+D:/Quartus_code/CICC_2025_Arm/ip/pll {D:/Quartus_code/CICC_2025_Arm/ip/pll/pll_100M_ip.v}
vlog -vlog01compat -work work +incdir+D:/Quartus_code/CICC_2025_Arm/db {D:/Quartus_code/CICC_2025_Arm/db/pll_100m_ip_altpll.v}

vlog -vlog01compat -work work +incdir+D:/Quartus_code/CICC_2025_Arm/rtl/SPI/test {D:/Quartus_code/CICC_2025_Arm/rtl/SPI/test/tb_test_SPI.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc"  tb_test_SPI

add wave *
view structure
view signals
run -all
