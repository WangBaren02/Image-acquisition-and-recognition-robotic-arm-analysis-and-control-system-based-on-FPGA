module test_send_location2robotic_arm
(
	input		sys_clk,
	input		sys_rst_n,

    input       start,

    output      pwm_0,
    output      pwm_1,
    output      pwm_2,
    output      pwm_3,
 //   output      pwm_4,

    output      air_pump
);
///////////////////////////////////
    wire    clk_1M;
    wire    locked;

    pll_test pll_test_inst 
    (
        .areset ( ~sys_rst_n ),
        .inclk0 ( sys_clk ),

        .c0     ( clk_1M ),
        .locked ( locked )
    );

    wire    rst_n;

    assign rst_n = sys_rst_n & locked;
/////////////////////////////////////////
    reg             start_reg;

    always@( posedge clk_1M or negedge rst_n )
        begin
            if(!rst_n) start_reg <= 1'b0;
            else start_reg <= start;
        end

    wire            image_process_done;

    assign image_process_done = (~start) & (start_reg);

//    reg             image_process_done;

//    always@( posedge clk_1M or negedge rst_n )
//        begin
//            if(!rst_n) image_process_done <= 1'b0;
//            else if( (!start) && (start_reg) ) image_process_done <= 1'b1;
//            else image_process_done <= 1'b0;
//        end
//////////////////////////////////
    wire    [3:0]   address_rd;
    wire            clk_rd;
    wire            en_rd;
    wire    [19:0]  image_process_data;

    rom_test rom_test_inst 
    (
        .address( address_rd ),
        .clock  ( clk_rd ),
        .rden   ( en_rd ),
        .q      ( image_process_data )
    );
///////////////////////////////////////////
    wire            loop_done;

    wire    [1:0]   color;
    wire    [1:0]   shape;

    wire    [7:0]   X;
    wire    [7:0]   Y;
    wire            image_process_data_valid;

    send_location send_location_inst
    (   
        .clk                        (clk_1M),       //模块时钟:1MHz
        .rst_n                      (rst_n),        //模块复位
        
        .image_process_data         (image_process_data),
        .image_process_done         (image_process_done),
        .loop_done                  (loop_done),
        
        .en_rd                      (en_rd),
        .address_rd                 (address_rd),
        .clk_rd                     (clk_rd),
    
        .color                      (color),
        .shape                      (shape),
        .X                          (X),
        .Y                          (Y),
        .image_process_data_valid   (image_process_data_valid)
    );
////////////////////////////////////////////////////////////////
    wire            mode;

    wire    [11:0]  duty_0;
    wire    [11:0]  duty_1;
    wire    [11:0]  duty_2;
    wire    [11:0]  duty_3;

    robotic_arm_low_clk robotic_arm_low_clk_inst            
    (
        .sys_clk                    (clk_1M),       //模块时钟:1MHz
        .sys_rst_n                  (rst_n),        //模块复位
        
        .X                          (X),                
        .Y                          (Y),
        .shape                      (shape), 
        .color                      (color), 
        .valid_image_process_data   (image_process_data_valid), //图像识别信息有效
    
        .DUTY_STEP                  (7'd10),
        .CNT_DELAY_DUTY             (20'd10000),

        .mode                       (mode),

        .duty_processed_0           (duty_0),
        .duty_processed_1           (duty_1),
        .duty_processed_2           (duty_2),
        .duty_processed_3           (duty_3),
    
        .pwm_0                      (pwm_0),        //PWM驱动舵机0
        .pwm_1                      (pwm_1),        //PWM驱动舵机1
        .pwm_2                      (pwm_2),        //PWM驱动舵机2
        .pwm_3                      (pwm_3),        //PWM驱动舵机3
//        .pwm_4                      (pwm_4),        //PWM驱动舵机4
        .air_pump                   (air_pump),     //气泵使能
    
        .loop_done                  (loop_done)     //完成一个物体放��?
    );

endmodule