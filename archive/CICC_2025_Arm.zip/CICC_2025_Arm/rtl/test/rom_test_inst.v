rom_test	rom_test_inst (
	.address ( address_sig ),
	.clock ( clock_sig ),
	.rden ( rden_sig ),
	.q ( q_sig )
	);
