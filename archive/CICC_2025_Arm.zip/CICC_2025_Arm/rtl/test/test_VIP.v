module test_VIP
(
	input				clk,
	input				rst_n,

	input				start_VIP,

	output 	reg [9:0]   VIP_X,
    output  reg [9:0]   VIP_Y,
    output  reg [1:0]   shape,
    output  reg [1:0]   color,
    output  reg [8:0]   catch_4_angle,
    output  reg [1:0]   release_triangle_pos,
    output  reg         VIP_done,

    input				loop_done,
    input				all_done
);
////////////////////////////////////
	wire		work_flag;

	assign work_flag = start_VIP || loop_done;

	reg 		work_flag_reg;

	always@( posedge clk or negedge rst_n )
		begin
			if(!rst_n) work_flag_reg <= 1'b0;
			else work_flag_reg <= work_flag;
		end
///////////////////////////////////////////////
	reg [4:0]	cnt_object;

	always@( posedge clk or negedge rst_n )
		begin
			if(!rst_n) cnt_object <= 5'd0;
			else if(work_flag) cnt_object <= cnt_object + 1'b1;
			else cnt_object <= cnt_object; 
		end
////////////////////////////////////////////////
	always@( posedge clk or negedge rst_n )
		begin
			if(!rst_n)
				begin
					VIP_X <= 10'd0;
					VIP_Y <= 10'd0;
					shape <= 2'd0;
					color <= 2'd0;
					catch_4_angle <= 9'd0;
					release_triangle_pos <= 2'd0;
					VIP_done <= 1'd0;
				end
			else if(work_flag_reg)
				begin
					case(cnt_object)
					5'd1:
						begin
							VIP_X <= 10'd1;
							VIP_Y <= 10'd1;
							shape <= 2'b1;
							color <= 2'b1;
							catch_4_angle <= 9'd1;
							release_triangle_pos <= 2'd1;
						end
					5'd2:
						begin
							VIP_X <= 10'd2;
							VIP_Y <= 10'd20;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd1;
						end
					5'd3:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd4:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd5:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd6:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd7:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd8:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd9:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd10:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd11:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					5'd12:
						begin
							VIP_X <= 10'd0;
							VIP_Y <= 10'd0;
							shape <= 2'b0;
							color <= 2'b0;
							catch_4_angle <= 9'd0;
							release_triangle_pos <= 2'd0;
						end
					default: ;
					endcase

					VIP_done <= 1'b1;
				end
			else
				begin
					VIP_X <= VIP_X;
					VIP_Y <= VIP_Y;
					shape <= shape;
					color <= color;
					catch_4_angle <= catch_4_angle;
					release_triangle_pos <= release_triangle_pos;
					VIP_done <= 1'b0;
				end
		end
endmodule