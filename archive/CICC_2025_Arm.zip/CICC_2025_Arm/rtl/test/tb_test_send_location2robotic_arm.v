`timescale 1ns/1ns

module tb_test_send_location2robotic_arm();

	reg		sys_clk;
	reg		sys_rst_n;
	reg		start;

	wire	pwm_0;
	wire	pwm_1;
	wire	pwm_2;
	wire	pwm_3;
//	wire	pwm_4;

	wire	air_pump;
	
	test_send_location2robotic_arm test_send_location2robotic_arm_inst
	(
		.sys_clk 	(sys_clk),
		.sys_rst_n 	(sys_rst_n),
	
	    .start 		(start),
	
	    .pwm_0		(pwm_0),
	    .pwm_1		(pwm_1),
	    .pwm_2		(pwm_2),
	    .pwm_3		(pwm_3),
//	    .pwm_4		(pwm_4),
	
	    .air_pump	(air_pump)
	);

	initial
		begin
			sys_clk = 1'b1;
			sys_rst_n <= 1'b0;
			start <= 1'b1;
			#1000
			sys_rst_n <= 1'b1;
			#1000
			start <= 1'b0;
			#1000
			start <= 1'b1;
		end

	always #1 sys_clk = ~ sys_clk;

endmodule